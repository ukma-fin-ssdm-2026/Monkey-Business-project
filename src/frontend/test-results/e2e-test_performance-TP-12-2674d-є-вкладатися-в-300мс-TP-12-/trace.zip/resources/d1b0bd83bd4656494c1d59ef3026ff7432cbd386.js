import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NewCardForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b39cee6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/NewCardForm.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=2b39cee6"; const useState = __vite__cjsImport3_react["useState"];
export function NewCardForm({ onSubmit, onCancel }) {
  _s();
  const [company, setCompany] = useState("");
  const [position, setPosition] = useState("");
  const [saving, setSaving] = useState(false);
  async function handleSubmit(e) {
    e.preventDefault();
    if (!company.trim() || !position.trim()) return;
    setSaving(true);
    try {
      await onSubmit(company.trim(), position.trim());
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxDEV("form", { className: "new-card-form", onSubmit: handleSubmit, children: [
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        autoFocus: true,
        placeholder: "Компанія",
        value: company,
        onChange: (e) => setCompany(e.target.value),
        maxLength: 200,
        required: true
      },
      void 0,
      false,
      {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/NewCardForm.tsx",
        lineNumber: 52,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        placeholder: "Посада",
        value: position,
        onChange: (e) => setPosition(e.target.value),
        maxLength: 200,
        required: true
      },
      void 0,
      false,
      {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/NewCardForm.tsx",
        lineNumber: 60,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "new-card-form-actions", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "submit", disabled: saving, children: "Додати" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/NewCardForm.tsx",
        lineNumber: 68,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "secondary", onClick: onCancel, children: "Скасувати" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/NewCardForm.tsx",
        lineNumber: 71,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/NewCardForm.tsx",
      lineNumber: 67,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/NewCardForm.tsx",
    lineNumber: 51,
    columnNumber: 5
  }, this);
}
_s(NewCardForm, "rhRdkOcbhRSPkk/lN18ajUkuaYc=");
_c = NewCardForm;
var _c;
$RefreshReg$(_c, "NewCardForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/NewCardForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/NewCardForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCTixTQUFvQkEsZ0JBQWdCO0FBTzdCLGdCQUFTQyxZQUFZLEVBQUVDLFVBQVVDLFNBQWdCLEdBQUc7QUFBQUMsS0FBQTtBQUN6RCxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSU4sU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ08sVUFBVUMsV0FBVyxJQUFJUixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDUyxRQUFRQyxTQUFTLElBQUlWLFNBQVMsS0FBSztBQUUxQyxpQkFBZVcsYUFBYUMsR0FBYztBQUN4Q0EsTUFBRUMsZUFBZTtBQUNqQixRQUFJLENBQUNSLFFBQVFTLEtBQUssS0FBSyxDQUFDUCxTQUFTTyxLQUFLLEVBQUc7QUFDekNKLGNBQVUsSUFBSTtBQUNkLFFBQUk7QUFDRixZQUFNUixTQUFTRyxRQUFRUyxLQUFLLEdBQUdQLFNBQVNPLEtBQUssQ0FBQztBQUFBLElBQ2hELFVBQUM7QUFDQ0osZ0JBQVUsS0FBSztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixVQUFVQyxjQUN4QztBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsYUFBWTtBQUFBLFFBQ1osT0FBT047QUFBQUEsUUFDUCxVQUFVLENBQUNPLE1BQU1OLFdBQVdNLEVBQUVHLE9BQU9DLEtBQUs7QUFBQSxRQUMxQyxXQUFXO0FBQUEsUUFDWCxVQUFRO0FBQUE7QUFBQSxNQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1VO0FBQUEsSUFFVjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsYUFBWTtBQUFBLFFBQ1osT0FBT1Q7QUFBQUEsUUFDUCxVQUFVLENBQUNLLE1BQU1KLFlBQVlJLEVBQUVHLE9BQU9DLEtBQUs7QUFBQSxRQUMzQyxXQUFXO0FBQUEsUUFDWCxVQUFRO0FBQUE7QUFBQSxNQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtVO0FBQUEsSUFFVix1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxVQUFVUCxRQUFPLHNCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsYUFBWSxTQUFTTixVQUFTLHlCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFSjtBQUFDQyxHQTNDZUgsYUFBVztBQUFBLEtBQVhBO0FBQVcsSUFBQWdCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTmV3Q2FyZEZvcm0iLCJvblN1Ym1pdCIsIm9uQ2FuY2VsIiwiX3MiLCJjb21wYW55Iiwic2V0Q29tcGFueSIsInBvc2l0aW9uIiwic2V0UG9zaXRpb24iLCJzYXZpbmciLCJzZXRTYXZpbmciLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJ0cmltIiwidGFyZ2V0IiwidmFsdWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOZXdDYXJkRm9ybS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiDQhtC90YHRgtGA0YPQvNC10L3RgjogQ2xhdWRlXG4gKiDQl9Cw0YHRgtC+0YHRg9Cy0LDQvdC90Y86INCc0ZbQvdGWLdGE0L7RgNC80LAg0YHRgtCy0L7RgNC10L3QvdGPINC60LDRgNGC0LrQuCDQsiDQutC+0LvQvtC90YbRliAoY29tcGFueSwgcG9zaXRpb24g4oCUXG4gKiDQvtCx0L7QsifRj9C30LrQvtCy0ZYg0L/QvtC70Y8gQ2FyZENyZWF0ZSDQt9GWIHNjaGVtYXMucHkpLlxuICog0JLQtdGA0LjRhNGW0LrQsNGG0ZbRjzog0J/QtdGA0LXQstGW0YDQtdC90L4g0YLQuNC/0Lgg0Lkg0LHRltC70LQuXG4gKi9cblxuaW1wb3J0IHsgRm9ybUV2ZW50LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBvblN1Ym1pdDogKGNvbXBhbnk6IHN0cmluZywgcG9zaXRpb246IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbiAgb25DYW5jZWw6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBOZXdDYXJkRm9ybSh7IG9uU3VibWl0LCBvbkNhbmNlbCB9OiBQcm9wcykge1xuICBjb25zdCBbY29tcGFueSwgc2V0Q29tcGFueV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Bvc2l0aW9uLCBzZXRQb3NpdGlvbl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoZTogRm9ybUV2ZW50KSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICghY29tcGFueS50cmltKCkgfHwgIXBvc2l0aW9uLnRyaW0oKSkgcmV0dXJuO1xuICAgIHNldFNhdmluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgb25TdWJtaXQoY29tcGFueS50cmltKCksIHBvc2l0aW9uLnRyaW0oKSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8Zm9ybSBjbGFzc05hbWU9XCJuZXctY2FyZC1mb3JtXCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XG4gICAgICA8aW5wdXRcbiAgICAgICAgYXV0b0ZvY3VzXG4gICAgICAgIHBsYWNlaG9sZGVyPVwi0JrQvtC80L/QsNC90ZbRj1wiXG4gICAgICAgIHZhbHVlPXtjb21wYW55fVxuICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbXBhbnkoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICBtYXhMZW5ndGg9ezIwMH1cbiAgICAgICAgcmVxdWlyZWRcbiAgICAgIC8+XG4gICAgICA8aW5wdXRcbiAgICAgICAgcGxhY2Vob2xkZXI9XCLQn9C+0YHQsNC00LBcIlxuICAgICAgICB2YWx1ZT17cG9zaXRpb259XG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UG9zaXRpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICBtYXhMZW5ndGg9ezIwMH1cbiAgICAgICAgcmVxdWlyZWRcbiAgICAgIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5ldy1jYXJkLWZvcm0tYWN0aW9uc1wiPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17c2F2aW5nfT5cbiAgICAgICAgICDQlNC+0LTQsNGC0LhcbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInNlY29uZGFyeVwiIG9uQ2xpY2s9e29uQ2FuY2VsfT5cbiAgICAgICAgICDQodC60LDRgdGD0LLQsNGC0LhcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Zvcm0+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9vbGVrc2lpdm9saWsvRG9jdW1lbnRzL0dpdEh1Yi9Nb25rZXktQnVzaW5lc3MtcHJvamVjdC9zcmMvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTmV3Q2FyZEZvcm0udHN4In0=