import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProtectedRoute.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b39cee6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/ProtectedRoute.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Navigate, Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=8b960ccb";
import { useAuth } from "/src/context/AuthContext.tsx";
export function ProtectedRoute() {
  _s();
  const { user, isReady } = useAuth();
  if (!isReady) return null;
  if (!user) return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/ProtectedRoute.tsx",
    lineNumber: 33,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/ProtectedRoute.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
}
_s(ProtectedRoute, "pOe0vdIq0Bvs2nYhYe/ZjMYVbx4=", false, function() {
  return [useAuth];
});
_c = ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/ProtectedRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/ProtectedRoute.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYW9COzs7Ozs7Ozs7Ozs7Ozs7OztBQU5wQixTQUFTQSxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLGVBQWU7QUFFakIsZ0JBQVNDLGlCQUFpQjtBQUFBQyxLQUFBO0FBQy9CLFFBQU0sRUFBRUMsTUFBTUMsUUFBUSxJQUFJSixRQUFRO0FBQ2xDLE1BQUksQ0FBQ0ksUUFBUyxRQUFPO0FBQ3JCLE1BQUksQ0FBQ0QsS0FBTSxRQUFPLHVCQUFDLFlBQVMsSUFBRyxVQUFTLFNBQU8sUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE2QjtBQUMvQyxTQUFPLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFPO0FBQ2hCO0FBQUNELEdBTGVELGdCQUFjO0FBQUEsVUFDRkQsT0FBTztBQUFBO0FBQUEsS0FEbkJDO0FBQWMsSUFBQUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTmF2aWdhdGUiLCJPdXRsZXQiLCJ1c2VBdXRoIiwiUHJvdGVjdGVkUm91dGUiLCJfcyIsInVzZXIiLCJpc1JlYWR5IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvdGVjdGVkUm91dGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICog0IbQvdGB0YLRgNGD0LzQtdC90YI6IENsYXVkZVxuICog0JfQsNGB0YLQvtGB0YPQstCw0L3QvdGPOiBSb3V0ZS1ndWFyZCDigJQg0L/Rg9GB0LrQsNGUINC00L4gL2JvYXJkKiDQu9C40YjQtSDQsNCy0YLQtdC90YLQuNGE0ZbQutC+0LLQsNC90LjRhVxuICog0LrQvtGA0LjRgdGC0YPQstCw0YfRltCyICjQtNC30LXRgNC60LDQu9C40YLRjCDQstC40LzQvtCz0YMgQmVhcmVyLdGC0L7QutC10L3QsCDQvdCwINCx0LXQutC10L3QtNGWLCBhdXRoLnB5KS5cbiAqINCS0LXRgNC40YTRltC60LDRhtGW0Y86INCf0LXRgNC10LLRltGA0LXQvdC+INGC0LjQv9C4INC5INCx0ZbQu9C0LlxuICovXG5cbmltcG9ydCB7IE5hdmlnYXRlLCBPdXRsZXQgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9jb250ZXh0L0F1dGhDb250ZXh0XCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBQcm90ZWN0ZWRSb3V0ZSgpIHtcbiAgY29uc3QgeyB1c2VyLCBpc1JlYWR5IH0gPSB1c2VBdXRoKCk7XG4gIGlmICghaXNSZWFkeSkgcmV0dXJuIG51bGw7XG4gIGlmICghdXNlcikgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9sb2dpblwiIHJlcGxhY2UgLz47XG4gIHJldHVybiA8T3V0bGV0IC8+O1xufVxuIl0sImZpbGUiOiIvVXNlcnMvb2xla3NpaXZvbGlrL0RvY3VtZW50cy9HaXRIdWIvTW9ua2V5LUJ1c2luZXNzLXByb2plY3Qvc3JjL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1Byb3RlY3RlZFJvdXRlLnRzeCJ9