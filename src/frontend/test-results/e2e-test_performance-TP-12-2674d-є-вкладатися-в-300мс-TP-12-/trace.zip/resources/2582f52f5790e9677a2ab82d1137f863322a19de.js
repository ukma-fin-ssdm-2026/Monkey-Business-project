import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CardItem.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b39cee6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardItem.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Draggable } from "/node_modules/.vite/deps/@hello-pangea_dnd.js?v=3e2b51ff";
const STATUS_LABEL = {
  active: "Активна",
  rejected: "Відмова",
  offer_accepted: "Офер"
};
function formatDeadline(iso) {
  if (!iso) return null;
  const date = new Date(iso);
  return date.toLocaleString("uk-UA", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}
function isOverdue(iso) {
  if (!iso) return false;
  return new Date(iso).getTime() < Date.now();
}
export function CardItem({ card, index, draggable, onOpen }) {
  const deadline = formatDeadline(card.deadline);
  return /* @__PURE__ */ jsxDEV(Draggable, { draggableId: card.id, index, isDragDisabled: !draggable, children: (provided, snapshot) => /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref: provided.innerRef,
      ...provided.draggableProps,
      ...provided.dragHandleProps,
      className: `card-item status-${card.status}${snapshot.isDragging ? " dragging" : ""}`,
      onClick: () => onOpen(card.id),
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "card-item-header", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "card-company", children: card.company }, void 0, false, {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardItem.tsx",
            lineNumber: 75,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `status-badge status-${card.status}`, children: STATUS_LABEL[card.status] }, void 0, false, {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardItem.tsx",
            lineNumber: 76,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardItem.tsx",
          lineNumber: 74,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "card-position", children: card.position }, void 0, false, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardItem.tsx",
          lineNumber: 80,
          columnNumber: 11
        }, this),
        deadline && /* @__PURE__ */ jsxDEV("div", { className: `card-deadline${isOverdue(card.deadline) ? " overdue" : ""}`, children: [
          "⏰ ",
          deadline
        ] }, void 0, true, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardItem.tsx",
          lineNumber: 82,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardItem.tsx",
      lineNumber: 65,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardItem.tsx",
    lineNumber: 63,
    columnNumber: 5
  }, this);
}
_c = CardItem;
var _c;
$RefreshReg$(_c, "CardItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardItem.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardItem.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURZOzs7Ozs7Ozs7Ozs7Ozs7O0FBaERaLFNBQVNBLGlCQUFpQjtBQUcxQixNQUFNQyxlQUFrRDtBQUFBLEVBQ3REQyxRQUFRO0FBQUEsRUFDUkMsVUFBVTtBQUFBLEVBQ1ZDLGdCQUFnQjtBQUNsQjtBQUVBLFNBQVNDLGVBQWVDLEtBQW1DO0FBQ3pELE1BQUksQ0FBQ0EsSUFBSyxRQUFPO0FBQ2pCLFFBQU1DLE9BQU8sSUFBSUMsS0FBS0YsR0FBRztBQUN6QixTQUFPQyxLQUFLRSxlQUFlLFNBQVM7QUFBQSxJQUNsQ0MsS0FBSztBQUFBLElBQ0xDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNIO0FBRUEsU0FBU0MsVUFBVVIsS0FBNkI7QUFDOUMsTUFBSSxDQUFDQSxJQUFLLFFBQU87QUFDakIsU0FBTyxJQUFJRSxLQUFLRixHQUFHLEVBQUVTLFFBQVEsSUFBSVAsS0FBS1EsSUFBSTtBQUM1QztBQVNPLGdCQUFTQyxTQUFTLEVBQUVDLE1BQU1DLE9BQU9DLFdBQVdDLE9BQWMsR0FBRztBQUNsRSxRQUFNQyxXQUFXakIsZUFBZWEsS0FBS0ksUUFBUTtBQUU3QyxTQUNFLHVCQUFDLGFBQVUsYUFBYUosS0FBS0ssSUFBSSxPQUFjLGdCQUFnQixDQUFDSCxXQUM3RCxXQUFDSSxVQUFVQyxhQUNWO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxLQUFLRCxTQUFTRTtBQUFBQSxNQUNkLEdBQUlGLFNBQVNHO0FBQUFBLE1BQ2IsR0FBSUgsU0FBU0k7QUFBQUEsTUFDYixXQUFXLG9CQUFvQlYsS0FBS1csTUFBTSxHQUN4Q0osU0FBU0ssYUFBYSxjQUFjLEVBQUU7QUFBQSxNQUV4QyxTQUFTLE1BQU1ULE9BQU9ILEtBQUtLLEVBQUU7QUFBQSxNQUU3QjtBQUFBLCtCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxnQkFBZ0JMLGVBQUthLFdBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFDN0MsdUJBQUMsVUFBSyxXQUFXLHVCQUF1QmIsS0FBS1csTUFBTSxJQUNoRDVCLHVCQUFhaUIsS0FBS1csTUFBTSxLQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFBaUJYLGVBQUtjLFlBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM3Q1YsWUFDQyx1QkFBQyxTQUFJLFdBQVcsZ0JBQWdCUixVQUFVSSxLQUFLSSxRQUFRLElBQUksYUFBYSxFQUFFLElBQUc7QUFBQTtBQUFBLFVBQ3hFQTtBQUFBQSxhQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUE7QUFBQSxJQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFxQkEsS0F2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlCQTtBQUVKO0FBQUNXLEtBL0JlaEI7QUFBUSxJQUFBZ0I7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRHJhZ2dhYmxlIiwiU1RBVFVTX0xBQkVMIiwiYWN0aXZlIiwicmVqZWN0ZWQiLCJvZmZlcl9hY2NlcHRlZCIsImZvcm1hdERlYWRsaW5lIiwiaXNvIiwiZGF0ZSIsIkRhdGUiLCJ0b0xvY2FsZVN0cmluZyIsImRheSIsIm1vbnRoIiwiaG91ciIsIm1pbnV0ZSIsImlzT3ZlcmR1ZSIsImdldFRpbWUiLCJub3ciLCJDYXJkSXRlbSIsImNhcmQiLCJpbmRleCIsImRyYWdnYWJsZSIsIm9uT3BlbiIsImRlYWRsaW5lIiwiaWQiLCJwcm92aWRlZCIsInNuYXBzaG90IiwiaW5uZXJSZWYiLCJkcmFnZ2FibGVQcm9wcyIsImRyYWdIYW5kbGVQcm9wcyIsInN0YXR1cyIsImlzRHJhZ2dpbmciLCJjb21wYW55IiwicG9zaXRpb24iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXJkSXRlbS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiDQhtC90YHRgtGA0YPQvNC10L3RgjogQ2xhdWRlXG4gKiDQl9Cw0YHRgtC+0YHRg9Cy0LDQvdC90Y86IERyYWdnYWJsZS3QutCw0YDRgtC60LAg0LLQsNC60LDQvdGB0ZbRlyDQsiDQutC+0LvQvtC90YbRliDigJQg0LrQvtC80L/QsNC90ZbRjywg0L/QvtGB0LDQtNCwLFxuICog0YHRgtCw0YLRg9GBIChDYXJkU3RhdHVzINC30ZYgc2NoZW1hcy5weSksINC/0YDQvtGB0YLRgNC+0YfQtdC90LjQuSDQtNC10LTQu9Cw0LnQvS5cbiAqINCS0LXRgNC40YTRltC60LDRhtGW0Y86INCf0LXRgNC10LLRltGA0LXQvdC+INGC0LjQv9C4INC5INCx0ZbQu9C0OyDQu9C+0LrQsNC70ZbQt9Cw0YbRltGPINC00LDRgtC4L9GH0LDRgdGDIOKAlCB1ay1VQS5cbiAqL1xuXG5pbXBvcnQgeyBEcmFnZ2FibGUgfSBmcm9tIFwiQGhlbGxvLXBhbmdlYS9kbmRcIjtcbmltcG9ydCB0eXBlIHsgQ2FyZE91dCB9IGZyb20gXCIuLi9hcGkvdHlwZXNcIjtcblxuY29uc3QgU1RBVFVTX0xBQkVMOiBSZWNvcmQ8Q2FyZE91dFtcInN0YXR1c1wiXSwgc3RyaW5nPiA9IHtcbiAgYWN0aXZlOiBcItCQ0LrRgtC40LLQvdCwXCIsXG4gIHJlamVjdGVkOiBcItCS0ZbQtNC80L7QstCwXCIsXG4gIG9mZmVyX2FjY2VwdGVkOiBcItCe0YTQtdGAXCIsXG59O1xuXG5mdW5jdGlvbiBmb3JtYXREZWFkbGluZShpc286IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKCFpc28pIHJldHVybiBudWxsO1xuICBjb25zdCBkYXRlID0gbmV3IERhdGUoaXNvKTtcbiAgcmV0dXJuIGRhdGUudG9Mb2NhbGVTdHJpbmcoXCJ1ay1VQVwiLCB7XG4gICAgZGF5OiBcIjItZGlnaXRcIixcbiAgICBtb250aDogXCIyLWRpZ2l0XCIsXG4gICAgaG91cjogXCIyLWRpZ2l0XCIsXG4gICAgbWludXRlOiBcIjItZGlnaXRcIixcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIGlzT3ZlcmR1ZShpc286IHN0cmluZyB8IG51bGwpOiBib29sZWFuIHtcbiAgaWYgKCFpc28pIHJldHVybiBmYWxzZTtcbiAgcmV0dXJuIG5ldyBEYXRlKGlzbykuZ2V0VGltZSgpIDwgRGF0ZS5ub3coKTtcbn1cblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgY2FyZDogQ2FyZE91dDtcbiAgaW5kZXg6IG51bWJlcjtcbiAgZHJhZ2dhYmxlOiBib29sZWFuO1xuICBvbk9wZW46IChjYXJkSWQ6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIENhcmRJdGVtKHsgY2FyZCwgaW5kZXgsIGRyYWdnYWJsZSwgb25PcGVuIH06IFByb3BzKSB7XG4gIGNvbnN0IGRlYWRsaW5lID0gZm9ybWF0RGVhZGxpbmUoY2FyZC5kZWFkbGluZSk7XG5cbiAgcmV0dXJuIChcbiAgICA8RHJhZ2dhYmxlIGRyYWdnYWJsZUlkPXtjYXJkLmlkfSBpbmRleD17aW5kZXh9IGlzRHJhZ0Rpc2FibGVkPXshZHJhZ2dhYmxlfT5cbiAgICAgIHsocHJvdmlkZWQsIHNuYXBzaG90KSA9PiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICByZWY9e3Byb3ZpZGVkLmlubmVyUmVmfVxuICAgICAgICAgIHsuLi5wcm92aWRlZC5kcmFnZ2FibGVQcm9wc31cbiAgICAgICAgICB7Li4ucHJvdmlkZWQuZHJhZ0hhbmRsZVByb3BzfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGNhcmQtaXRlbSBzdGF0dXMtJHtjYXJkLnN0YXR1c30ke1xuICAgICAgICAgICAgc25hcHNob3QuaXNEcmFnZ2luZyA/IFwiIGRyYWdnaW5nXCIgOiBcIlwiXG4gICAgICAgICAgfWB9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25PcGVuKGNhcmQuaWQpfVxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWl0ZW0taGVhZGVyXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXJkLWNvbXBhbnlcIj57Y2FyZC5jb21wYW55fTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHN0YXR1cy1iYWRnZSBzdGF0dXMtJHtjYXJkLnN0YXR1c31gfT5cbiAgICAgICAgICAgICAge1NUQVRVU19MQUJFTFtjYXJkLnN0YXR1c119XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLXBvc2l0aW9uXCI+e2NhcmQucG9zaXRpb259PC9kaXY+XG4gICAgICAgICAge2RlYWRsaW5lICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgY2FyZC1kZWFkbGluZSR7aXNPdmVyZHVlKGNhcmQuZGVhZGxpbmUpID8gXCIgb3ZlcmR1ZVwiIDogXCJcIn1gfT5cbiAgICAgICAgICAgICAg4o+wIHtkZWFkbGluZX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L0RyYWdnYWJsZT5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL29sZWtzaWl2b2xpay9Eb2N1bWVudHMvR2l0SHViL01vbmtleS1CdXNpbmVzcy1wcm9qZWN0L3NyYy9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9DYXJkSXRlbS50c3gifQ==