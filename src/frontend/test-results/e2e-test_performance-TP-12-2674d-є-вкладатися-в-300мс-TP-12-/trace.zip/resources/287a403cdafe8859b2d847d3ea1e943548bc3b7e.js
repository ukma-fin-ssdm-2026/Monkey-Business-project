import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/StageColumn.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b39cee6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Droppable } from "/node_modules/.vite/deps/@hello-pangea_dnd.js?v=3e2b51ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=2b39cee6"; const useState = __vite__cjsImport4_react["useState"];
import { CardItem } from "/src/components/CardItem.tsx";
import { NewCardForm } from "/src/components/NewCardForm.tsx";
export function StageColumn({
  stage,
  cards,
  canWrite,
  onOpenCard,
  onAddCard,
  onRenameStage,
  onDeleteStage
}) {
  _s();
  const [adding, setAdding] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState(stage.name);
  async function saveName() {
    setEditingName(false);
    const trimmed = nameDraft.trim();
    if (trimmed && trimmed !== stage.name) {
      await onRenameStage(stage.id, trimmed);
    } else {
      setNameDraft(stage.name);
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "stage-column", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "stage-header", children: [
      editingName ? /* @__PURE__ */ jsxDEV(
        "input",
        {
          className: "stage-name-input",
          value: nameDraft,
          autoFocus: true,
          maxLength: 100,
          onChange: (e) => setNameDraft(e.target.value),
          onBlur: saveName,
          onKeyDown: (e) => {
            if (e.key === "Enter") e.target.blur();
            if (e.key === "Escape") {
              setNameDraft(stage.name);
              setEditingName(false);
            }
          }
        },
        void 0,
        false,
        {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
          lineNumber: 72,
          columnNumber: 9
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        "h3",
        {
          onClick: () => canWrite && setEditingName(true),
          title: canWrite ? "Клацніть, щоб перейменувати" : void 0,
          children: stage.name
        },
        void 0,
        false,
        {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
          lineNumber: 88,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("span", { className: "stage-count", children: cards.length }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
        lineNumber: 95,
        columnNumber: 9
      }, this),
      canWrite && /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "icon-button",
          title: "Видалити етап",
          onClick: () => onDeleteStage(stage.id),
          children: "✕"
        },
        void 0,
        false,
        {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
          lineNumber: 97,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
      lineNumber: 70,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Droppable, { droppableId: stage.id, isDropDisabled: !canWrite, children: (provided, snapshot) => /* @__PURE__ */ jsxDEV(
      "div",
      {
        ref: provided.innerRef,
        ...provided.droppableProps,
        className: `stage-body${snapshot.isDraggingOver ? " drag-over" : ""}`,
        children: [
          cards.map(
            (card, index) => /* @__PURE__ */ jsxDEV(
              CardItem,
              {
                card,
                index,
                draggable: canWrite,
                onOpen: onOpenCard
              },
              card.id,
              false,
              {
                fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
                lineNumber: 115,
                columnNumber: 11
              },
              this
            )
          ),
          provided.placeholder
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
        lineNumber: 109,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
      lineNumber: 107,
      columnNumber: 7
    }, this),
    canWrite && (adding ? /* @__PURE__ */ jsxDEV(
      NewCardForm,
      {
        onSubmit: async (company, position) => {
          await onAddCard(stage.id, company, position);
          setAdding(false);
        },
        onCancel: () => setAdding(false)
      },
      void 0,
      false,
      {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
        lineNumber: 130,
        columnNumber: 7
      },
      this
    ) : /* @__PURE__ */ jsxDEV("button", { className: "add-card-button", onClick: () => setAdding(true), children: "+ Картка" }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
      lineNumber: 138,
      columnNumber: 7
    }, this))
  ] }, void 0, true, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx",
    lineNumber: 69,
    columnNumber: 5
  }, this);
}
_s(StageColumn, "Muv0h27PHmKCzZRfJyWTeKRDp6c=");
_c = StageColumn;
var _c;
$RefreshReg$(_c, "StageColumn");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/StageColumn.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNDVixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxtQkFBbUI7QUFZckIsZ0JBQVNDLFlBQVk7QUFBQSxFQUMxQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDSyxHQUFHO0FBQUFDLEtBQUE7QUFDUixRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWIsU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQ2MsYUFBYUMsY0FBYyxJQUFJZixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDZ0IsV0FBV0MsWUFBWSxJQUFJakIsU0FBU0ksTUFBTWMsSUFBSTtBQUVyRCxpQkFBZUMsV0FBVztBQUN4QkosbUJBQWUsS0FBSztBQUNwQixVQUFNSyxVQUFVSixVQUFVSyxLQUFLO0FBQy9CLFFBQUlELFdBQVdBLFlBQVloQixNQUFNYyxNQUFNO0FBQ3JDLFlBQU1ULGNBQWNMLE1BQU1rQixJQUFJRixPQUFPO0FBQUEsSUFDdkMsT0FBTztBQUNMSCxtQkFBYWIsTUFBTWMsSUFBSTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGdCQUNaSjtBQUFBQSxvQkFDQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsT0FBT0U7QUFBQUEsVUFDUDtBQUFBLFVBQ0EsV0FBVztBQUFBLFVBQ1gsVUFBVSxDQUFDTyxNQUFNTixhQUFhTSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsVUFDNUMsUUFBUU47QUFBQUEsVUFDUixXQUFXLENBQUNJLE1BQU07QUFDaEIsZ0JBQUlBLEVBQUVHLFFBQVEsUUFBUyxDQUFDSCxFQUFFQyxPQUE0QkcsS0FBSztBQUMzRCxnQkFBSUosRUFBRUcsUUFBUSxVQUFVO0FBQ3RCVCwyQkFBYWIsTUFBTWMsSUFBSTtBQUN2QkgsNkJBQWUsS0FBSztBQUFBLFlBQ3RCO0FBQUEsVUFDRjtBQUFBO0FBQUEsUUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFhSSxJQUdKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1ULFlBQVlTLGVBQWUsSUFBSTtBQUFBLFVBQzlDLE9BQU9ULFdBQVcsZ0NBQWdDc0I7QUFBQUEsVUFFakR4QixnQkFBTWM7QUFBQUE7QUFBQUEsUUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLE1BRUYsdUJBQUMsVUFBSyxXQUFVLGVBQWViLGdCQUFNd0IsVUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLE1BQzNDdkIsWUFDQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsT0FBTTtBQUFBLFVBQ04sU0FBUyxNQUFNSSxjQUFjTixNQUFNa0IsRUFBRTtBQUFBLFVBQUU7QUFBQTtBQUFBLFFBSHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQTtBQUFBLElBRUEsdUJBQUMsYUFBVSxhQUFhbEIsTUFBTWtCLElBQUksZ0JBQWdCLENBQUNoQixVQUNoRCxXQUFDd0IsVUFBVUMsYUFDVjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsS0FBS0QsU0FBU0U7QUFBQUEsUUFDZCxHQUFJRixTQUFTRztBQUFBQSxRQUNiLFdBQVcsYUFBYUYsU0FBU0csaUJBQWlCLGVBQWUsRUFBRTtBQUFBLFFBRWxFN0I7QUFBQUEsZ0JBQU04QjtBQUFBQSxZQUFJLENBQUNDLE1BQU1DLFVBQ2hCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUM7QUFBQSxnQkFDQTtBQUFBLGdCQUNBLFdBQVcvQjtBQUFBQSxnQkFDWCxRQUFRQztBQUFBQTtBQUFBQSxjQUpINkIsS0FBS2Q7QUFBQUEsY0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3FCO0FBQUEsVUFFdEI7QUFBQSxVQUNBUSxTQUFTUTtBQUFBQTtBQUFBQTtBQUFBQSxNQWRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWVBLEtBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxJQUVDaEMsYUFDRU0sU0FDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsVUFBVSxPQUFPMkIsU0FBU0MsYUFBYTtBQUNyQyxnQkFBTWhDLFVBQVVKLE1BQU1rQixJQUFJaUIsU0FBU0MsUUFBUTtBQUMzQzNCLG9CQUFVLEtBQUs7QUFBQSxRQUNqQjtBQUFBLFFBQ0EsVUFBVSxNQUFNQSxVQUFVLEtBQUs7QUFBQTtBQUFBLE1BTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUttQyxJQUduQyx1QkFBQyxZQUFPLFdBQVUsbUJBQWtCLFNBQVMsTUFBTUEsVUFBVSxJQUFJLEdBQUUsd0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BdkVOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5RUE7QUFFSjtBQUFDRixHQW5HZVIsYUFBVztBQUFBLEtBQVhBO0FBQVcsSUFBQXNDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkRyb3BwYWJsZSIsInVzZVN0YXRlIiwiQ2FyZEl0ZW0iLCJOZXdDYXJkRm9ybSIsIlN0YWdlQ29sdW1uIiwic3RhZ2UiLCJjYXJkcyIsImNhbldyaXRlIiwib25PcGVuQ2FyZCIsIm9uQWRkQ2FyZCIsIm9uUmVuYW1lU3RhZ2UiLCJvbkRlbGV0ZVN0YWdlIiwiX3MiLCJhZGRpbmciLCJzZXRBZGRpbmciLCJlZGl0aW5nTmFtZSIsInNldEVkaXRpbmdOYW1lIiwibmFtZURyYWZ0Iiwic2V0TmFtZURyYWZ0IiwibmFtZSIsInNhdmVOYW1lIiwidHJpbW1lZCIsInRyaW0iLCJpZCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImtleSIsImJsdXIiLCJ1bmRlZmluZWQiLCJsZW5ndGgiLCJwcm92aWRlZCIsInNuYXBzaG90IiwiaW5uZXJSZWYiLCJkcm9wcGFibGVQcm9wcyIsImlzRHJhZ2dpbmdPdmVyIiwibWFwIiwiY2FyZCIsImluZGV4IiwicGxhY2Vob2xkZXIiLCJjb21wYW55IiwicG9zaXRpb24iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTdGFnZUNvbHVtbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiDQhtC90YHRgtGA0YPQvNC10L3RgjogQ2xhdWRlXG4gKiDQl9Cw0YHRgtC+0YHRg9Cy0LDQvdC90Y86INCa0L7Qu9C+0L3QutCwINC10YLQsNC/0YMg0LTQvtGI0LrQuCDigJQg0YHQv9C40YHQvtC6INC60LDRgNGC0L7QuiAoZHJvcHBhYmxlLdC30L7QvdCwKSxcbiAqINC/0LXRgNC10LnQvNC10L3Rg9Cy0LDQvdC90Y8v0LLQuNC00LDQu9C10L3QvdGPINC10YLQsNC/0YMgKFBBVENIL0RFTEVURSAuLi4vc3RhZ2VzL3tpZH0pLCDRhNC+0YDQvNCwXG4gKiDQtNC+0LTQsNCy0LDQvdC90Y8g0LrQsNGA0YLQutC4LlxuICog0JLQtdGA0LjRhNGW0LrQsNGG0ZbRjzog0J/QtdGA0LXQstGW0YDQtdC90L4g0YLQuNC/0Lgg0Lkg0LHRltC70LQ7INC/0L7QstC10LTRltC90LrQsCA0MDkg0L/RgNC4INCy0LjQtNCw0LvQtdC90L3RllxuICog0L3QtdC/0L7RgNC+0LbQvdGM0L7Qs9C+INC10YLQsNC/0YMg0L/QvtC60LvQsNC00LDRlNGC0YzRgdGPINC90LAg0L7QsdGA0L7QsdC60YMg0L/QvtC80LjQu9C60Lgg0LIgQm9hcmRQYWdlLlxuICovXG5cbmltcG9ydCB7IERyb3BwYWJsZSB9IGZyb20gXCJAaGVsbG8tcGFuZ2VhL2RuZFwiO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgQ2FyZE91dCwgU3RhZ2VPdXQgfSBmcm9tIFwiLi4vYXBpL3R5cGVzXCI7XG5pbXBvcnQgeyBDYXJkSXRlbSB9IGZyb20gXCIuL0NhcmRJdGVtXCI7XG5pbXBvcnQgeyBOZXdDYXJkRm9ybSB9IGZyb20gXCIuL05ld0NhcmRGb3JtXCI7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIHN0YWdlOiBTdGFnZU91dDtcbiAgY2FyZHM6IENhcmRPdXRbXTtcbiAgY2FuV3JpdGU6IGJvb2xlYW47XG4gIG9uT3BlbkNhcmQ6IChjYXJkSWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgb25BZGRDYXJkOiAoc3RhZ2VJZDogc3RyaW5nLCBjb21wYW55OiBzdHJpbmcsIHBvc2l0aW9uOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD47XG4gIG9uUmVuYW1lU3RhZ2U6IChzdGFnZUlkOiBzdHJpbmcsIG5hbWU6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbiAgb25EZWxldGVTdGFnZTogKHN0YWdlSWQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFN0YWdlQ29sdW1uKHtcbiAgc3RhZ2UsXG4gIGNhcmRzLFxuICBjYW5Xcml0ZSxcbiAgb25PcGVuQ2FyZCxcbiAgb25BZGRDYXJkLFxuICBvblJlbmFtZVN0YWdlLFxuICBvbkRlbGV0ZVN0YWdlLFxufTogUHJvcHMpIHtcbiAgY29uc3QgW2FkZGluZywgc2V0QWRkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2VkaXRpbmdOYW1lLCBzZXRFZGl0aW5nTmFtZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtuYW1lRHJhZnQsIHNldE5hbWVEcmFmdF0gPSB1c2VTdGF0ZShzdGFnZS5uYW1lKTtcblxuICBhc3luYyBmdW5jdGlvbiBzYXZlTmFtZSgpIHtcbiAgICBzZXRFZGl0aW5nTmFtZShmYWxzZSk7XG4gICAgY29uc3QgdHJpbW1lZCA9IG5hbWVEcmFmdC50cmltKCk7XG4gICAgaWYgKHRyaW1tZWQgJiYgdHJpbW1lZCAhPT0gc3RhZ2UubmFtZSkge1xuICAgICAgYXdhaXQgb25SZW5hbWVTdGFnZShzdGFnZS5pZCwgdHJpbW1lZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldE5hbWVEcmFmdChzdGFnZS5uYW1lKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhZ2UtY29sdW1uXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YWdlLWhlYWRlclwiPlxuICAgICAgICB7ZWRpdGluZ05hbWUgPyAoXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzdGFnZS1uYW1lLWlucHV0XCJcbiAgICAgICAgICAgIHZhbHVlPXtuYW1lRHJhZnR9XG4gICAgICAgICAgICBhdXRvRm9jdXNcbiAgICAgICAgICAgIG1heExlbmd0aD17MTAwfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROYW1lRHJhZnQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgb25CbHVyPXtzYXZlTmFtZX1cbiAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IHtcbiAgICAgICAgICAgICAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIpIChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS5ibHVyKCk7XG4gICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gXCJFc2NhcGVcIikge1xuICAgICAgICAgICAgICAgIHNldE5hbWVEcmFmdChzdGFnZS5uYW1lKTtcbiAgICAgICAgICAgICAgICBzZXRFZGl0aW5nTmFtZShmYWxzZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8aDNcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNhbldyaXRlICYmIHNldEVkaXRpbmdOYW1lKHRydWUpfVxuICAgICAgICAgICAgdGl0bGU9e2NhbldyaXRlID8gXCLQmtC70LDRhtC90ZbRgtGMLCDRidC+0LEg0L/QtdGA0LXQudC80LXQvdGD0LLQsNGC0LhcIiA6IHVuZGVmaW5lZH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7c3RhZ2UubmFtZX1cbiAgICAgICAgICA8L2gzPlxuICAgICAgICApfVxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdGFnZS1jb3VudFwiPntjYXJkcy5sZW5ndGh9PC9zcGFuPlxuICAgICAgICB7Y2FuV3JpdGUgJiYgKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImljb24tYnV0dG9uXCJcbiAgICAgICAgICAgIHRpdGxlPVwi0JLQuNC00LDQu9C40YLQuCDQtdGC0LDQv1wiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkRlbGV0ZVN0YWdlKHN0YWdlLmlkKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDinJVcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8RHJvcHBhYmxlIGRyb3BwYWJsZUlkPXtzdGFnZS5pZH0gaXNEcm9wRGlzYWJsZWQ9eyFjYW5Xcml0ZX0+XG4gICAgICAgIHsocHJvdmlkZWQsIHNuYXBzaG90KSA9PiAoXG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgcmVmPXtwcm92aWRlZC5pbm5lclJlZn1cbiAgICAgICAgICAgIHsuLi5wcm92aWRlZC5kcm9wcGFibGVQcm9wc31cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHN0YWdlLWJvZHkke3NuYXBzaG90LmlzRHJhZ2dpbmdPdmVyID8gXCIgZHJhZy1vdmVyXCIgOiBcIlwifWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2NhcmRzLm1hcCgoY2FyZCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgPENhcmRJdGVtXG4gICAgICAgICAgICAgICAga2V5PXtjYXJkLmlkfVxuICAgICAgICAgICAgICAgIGNhcmQ9e2NhcmR9XG4gICAgICAgICAgICAgICAgaW5kZXg9e2luZGV4fVxuICAgICAgICAgICAgICAgIGRyYWdnYWJsZT17Y2FuV3JpdGV9XG4gICAgICAgICAgICAgICAgb25PcGVuPXtvbk9wZW5DYXJkfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICB7cHJvdmlkZWQucGxhY2Vob2xkZXJ9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L0Ryb3BwYWJsZT5cblxuICAgICAge2NhbldyaXRlICYmXG4gICAgICAgIChhZGRpbmcgPyAoXG4gICAgICAgICAgPE5ld0NhcmRGb3JtXG4gICAgICAgICAgICBvblN1Ym1pdD17YXN5bmMgKGNvbXBhbnksIHBvc2l0aW9uKSA9PiB7XG4gICAgICAgICAgICAgIGF3YWl0IG9uQWRkQ2FyZChzdGFnZS5pZCwgY29tcGFueSwgcG9zaXRpb24pO1xuICAgICAgICAgICAgICBzZXRBZGRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRBZGRpbmcoZmFsc2UpfVxuICAgICAgICAgIC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhZGQtY2FyZC1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRBZGRpbmcodHJ1ZSl9PlxuICAgICAgICAgICAgKyDQmtCw0YDRgtC60LBcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9vbGVrc2lpdm9saWsvRG9jdW1lbnRzL0dpdEh1Yi9Nb25rZXktQnVzaW5lc3MtcHJvamVjdC9zcmMvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvU3RhZ2VDb2x1bW4udHN4In0=