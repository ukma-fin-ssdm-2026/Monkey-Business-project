import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/BoardPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b39cee6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { DragDropContext } from "/node_modules/.vite/deps/@hello-pangea_dnd.js?v=3e2b51ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=2b39cee6"; const useCallback = __vite__cjsImport4_react["useCallback"]; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=8b960ccb";
import { api, ApiError } from "/src/api/client.ts";
import { useAuth } from "/src/context/AuthContext.tsx";
import { StageColumn } from "/src/components/StageColumn.tsx";
import { CardModal } from "/src/components/CardModal.tsx";
async function fetchAllCards(boardId) {
  const limit = 100;
  let offset = 0;
  const all = [];
  while (true) {
    const page = await api.listCards(boardId, limit, offset);
    all.push(...page.items);
    if (all.length >= page.pagination.total || page.items.length === 0) break;
    offset += limit;
  }
  return all;
}
export function BoardPage() {
  _s();
  const { user, boardId, setBoardId, logout } = useAuth();
  const navigate = useNavigate();
  const [stages, setStages] = useState([]);
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCardId, setSelectedCardId] = useState(null);
  const canWrite = user?.role === "candidate" || user?.role === "admin";
  const load = useCallback(async () => {
    if (!boardId) return;
    setLoading(true);
    setError(null);
    try {
      const [stagesData, cardsData] = await Promise.all(
        [
          api.listStages(boardId),
          fetchAllCards(boardId)
        ]
      );
      setStages([...stagesData].sort((a, b) => a.order_index - b.order_index));
      setCards(cardsData);
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
      } else {
        setError(err instanceof Error ? err.message : "Не вдалося завантажити дошку");
      }
    } finally {
      setLoading(false);
    }
  }, [boardId]);
  useEffect(() => {
    load();
  }, [load]);
  useEffect(() => {
    if (!boardId) navigate("/board/setup", { replace: true });
  }, [boardId, navigate]);
  if (!boardId) {
    return null;
  }
  async function handleDragEnd(result) {
    if (!boardId || !canWrite) return;
    const { destination, source, draggableId } = result;
    if (!destination) return;
    if (destination.droppableId === source.droppableId && destination.index === source.index) {
      return;
    }
    const card = cards.find((c) => c.id === draggableId);
    if (!card) return;
    const previousCards = cards;
    const withoutCard = cards.filter((c) => c.id !== draggableId);
    const destCards = withoutCard.filter((c) => c.stage_id === destination.droppableId).sort((a, b) => a.position_index - b.position_index);
    destCards.splice(destination.index, 0, {
      ...card,
      stage_id: destination.droppableId,
      position_index: destination.index
    });
    const rest = withoutCard.filter((c) => c.stage_id !== destination.droppableId);
    setCards([...rest, ...destCards]);
    try {
      await api.moveCard(boardId, draggableId, {
        stage_id: destination.droppableId,
        position_index: destination.index
      });
      await load();
    } catch (err) {
      setCards(previousCards);
      setError(err instanceof ApiError ? err.message : "Не вдалося перемістити картку");
    }
  }
  async function handleAddCard(stageId, company, position) {
    if (!boardId) return;
    try {
      await api.createCard(boardId, { company, position, stage_id: stageId });
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося створити картку");
    }
  }
  async function handleAddStage() {
    if (!boardId) return;
    const name = window.prompt("Назва нового етапу");
    if (!name || !name.trim()) return;
    try {
      await api.createStage(boardId, { name: name.trim() });
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося створити етап");
    }
  }
  async function handleRenameStage(stageId, name) {
    if (!boardId) return;
    try {
      await api.updateStage(boardId, stageId, { name });
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося перейменувати етап");
    }
  }
  async function handleDeleteStage(stageId) {
    if (!boardId) return;
    if (!window.confirm("Видалити цей етап?")) return;
    try {
      await api.deleteStage(boardId, stageId);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося видалити етап");
    }
  }
  const selectedCard = cards.find((c) => c.id === selectedCardId) ?? null;
  return /* @__PURE__ */ jsxDEV("div", { className: "board-page", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "board-topbar", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { children: "Tech Interview Board" }, void 0, false, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
          lineNumber: 192,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "board-id-hint", children: [
          "board_id: ",
          boardId
        ] }, void 0, true, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
          lineNumber: 193,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
        lineNumber: 191,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "board-topbar-actions", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "current-user", children: [
          user?.email,
          " (",
          user?.role,
          ")"
        ] }, void 0, true, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
          lineNumber: 196,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            className: "secondary",
            onClick: () => navigate("/board/setup"),
            children: "Змінити дошку"
          },
          void 0,
          false,
          {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
            lineNumber: 199,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("button", { className: "secondary", onClick: logout, children: "Вийти" }, void 0, false, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
          lineNumber: 205,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
        lineNumber: 195,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
      lineNumber: 190,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "banner-error", children: [
      error,
      /* @__PURE__ */ jsxDEV("button", { className: "icon-button", onClick: () => setError(null), children: "✕" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
        lineNumber: 214,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
      lineNumber: 212,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("p", { className: "board-status", children: "Завантаження дошки..." }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
      lineNumber: 221,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(DragDropContext, { onDragEnd: handleDragEnd, children: /* @__PURE__ */ jsxDEV("div", { className: "board-columns", children: [
      stages.map(
        (stage) => /* @__PURE__ */ jsxDEV(
          StageColumn,
          {
            stage,
            cards: cards.filter((c) => c.stage_id === stage.id).sort((a, b) => a.position_index - b.position_index),
            canWrite: !!canWrite,
            onOpenCard: setSelectedCardId,
            onAddCard: handleAddCard,
            onRenameStage: handleRenameStage,
            onDeleteStage: handleDeleteStage
          },
          stage.id,
          false,
          {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
            lineNumber: 226,
            columnNumber: 11
          },
          this
        )
      ),
      canWrite && /* @__PURE__ */ jsxDEV("button", { className: "add-stage-button", onClick: handleAddStage, children: "+ Етап" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
        lineNumber: 240,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
      lineNumber: 224,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
      lineNumber: 223,
      columnNumber: 7
    }, this),
    selectedCard && boardId && /* @__PURE__ */ jsxDEV(
      CardModal,
      {
        boardId,
        card: selectedCard,
        canWrite: !!canWrite,
        onClose: () => setSelectedCardId(null),
        onUpdated: (updated) => {
          setCards((prev) => prev.map((c) => c.id === updated.id ? updated : c));
        },
        onDeleted: (cardId) => {
          setCards((prev) => prev.filter((c) => c.id !== cardId));
          setSelectedCardId(null);
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
        lineNumber: 249,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx",
    lineNumber: 189,
    columnNumber: 5
  }, this);
}
_s(BoardPage, "0f8btgrPAVsvYucOg4RWAGa7hRI=", false, function() {
  return [useAuth, useNavigate];
});
_c = BoardPage;
var _c;
$RefreshReg$(_c, "BoardPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEtVOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhLVixTQUFTQSx1QkFBd0M7QUFDakQsU0FBU0MsYUFBYUMsV0FBV0MsZ0JBQWdCO0FBQ2pELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxLQUFLQyxnQkFBZ0I7QUFDOUIsU0FBU0MsZUFBZTtBQUV4QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBRTFCLGVBQWVDLGNBQWNDLFNBQXFDO0FBQ2hFLFFBQU1DLFFBQVE7QUFDZCxNQUFJQyxTQUFTO0FBQ2IsUUFBTUMsTUFBaUI7QUFJdkIsU0FBTyxNQUFNO0FBQ1gsVUFBTUMsT0FBTyxNQUFNVixJQUFJVyxVQUFVTCxTQUFTQyxPQUFPQyxNQUFNO0FBQ3ZEQyxRQUFJRyxLQUFLLEdBQUdGLEtBQUtHLEtBQUs7QUFDdEIsUUFBSUosSUFBSUssVUFBVUosS0FBS0ssV0FBV0MsU0FBU04sS0FBS0csTUFBTUMsV0FBVyxFQUFHO0FBQ3BFTixjQUFVRDtBQUFBQSxFQUNaO0FBQ0EsU0FBT0U7QUFDVDtBQUVPLGdCQUFTUSxZQUFZO0FBQUFDLEtBQUE7QUFDMUIsUUFBTSxFQUFFQyxNQUFNYixTQUFTYyxZQUFZQyxPQUFPLElBQUluQixRQUFRO0FBQ3RELFFBQU1vQixXQUFXdkIsWUFBWTtBQUU3QixRQUFNLENBQUN3QixRQUFRQyxTQUFTLElBQUkxQixTQUFxQixFQUFFO0FBQ25ELFFBQU0sQ0FBQzJCLE9BQU9DLFFBQVEsSUFBSTVCLFNBQW9CLEVBQUU7QUFDaEQsUUFBTSxDQUFDNkIsU0FBU0MsVUFBVSxJQUFJOUIsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQytCLE9BQU9DLFFBQVEsSUFBSWhDLFNBQXdCLElBQUk7QUFDdEQsUUFBTSxDQUFDaUMsZ0JBQWdCQyxpQkFBaUIsSUFBSWxDLFNBQXdCLElBQUk7QUFFeEUsUUFBTW1DLFdBQVdkLE1BQU1lLFNBQVMsZUFBZWYsTUFBTWUsU0FBUztBQUU5RCxRQUFNQyxPQUFPdkMsWUFBWSxZQUFZO0FBQ25DLFFBQUksQ0FBQ1UsUUFBUztBQUNkc0IsZUFBVyxJQUFJO0FBQ2ZFLGFBQVMsSUFBSTtBQUNiLFFBQUk7QUFDRixZQUFNLENBQUNNLFlBQVlDLFNBQVMsSUFBSSxNQUFNQyxRQUFRN0I7QUFBQUEsUUFBSTtBQUFBLFVBQ2hEVCxJQUFJdUMsV0FBV2pDLE9BQU87QUFBQSxVQUN0QkQsY0FBY0MsT0FBTztBQUFBLFFBQUM7QUFBQSxNQUN2QjtBQUNEa0IsZ0JBQVUsQ0FBQyxHQUFHWSxVQUFVLEVBQUVJLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUQsRUFBRUUsY0FBY0QsRUFBRUMsV0FBVyxDQUFDO0FBQ3ZFakIsZUFBU1csU0FBUztBQUFBLElBQ3BCLFNBQVNPLEtBQUs7QUFDWixVQUFJQSxlQUFlM0MsVUFBVTtBQUMzQjZCLGlCQUFTYyxJQUFJQyxPQUFPO0FBQUEsTUFDdEIsT0FBTztBQUNMZixpQkFBU2MsZUFBZUUsUUFBUUYsSUFBSUMsVUFBVSw4QkFBOEI7QUFBQSxNQUM5RTtBQUFBLElBQ0YsVUFBQztBQUNDakIsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRixHQUFHLENBQUN0QixPQUFPLENBQUM7QUFFWlQsWUFBVSxNQUFNO0FBQ2RzQyxTQUFLO0FBQUEsRUFDUCxHQUFHLENBQUNBLElBQUksQ0FBQztBQUVUdEMsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDUyxRQUFTZ0IsVUFBUyxnQkFBZ0IsRUFBRXlCLFNBQVMsS0FBSyxDQUFDO0FBQUEsRUFDMUQsR0FBRyxDQUFDekMsU0FBU2dCLFFBQVEsQ0FBQztBQUV0QixNQUFJLENBQUNoQixTQUFTO0FBQ1osV0FBTztBQUFBLEVBQ1Q7QUFFQSxpQkFBZTBDLGNBQWNDLFFBQW9CO0FBQy9DLFFBQUksQ0FBQzNDLFdBQVcsQ0FBQzJCLFNBQVU7QUFDM0IsVUFBTSxFQUFFaUIsYUFBYUMsUUFBUUMsWUFBWSxJQUFJSDtBQUM3QyxRQUFJLENBQUNDLFlBQWE7QUFDbEIsUUFDRUEsWUFBWUcsZ0JBQWdCRixPQUFPRSxlQUNuQ0gsWUFBWUksVUFBVUgsT0FBT0csT0FDN0I7QUFDQTtBQUFBLElBQ0Y7QUFFQSxVQUFNQyxPQUFPOUIsTUFBTStCLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRUMsT0FBT04sV0FBVztBQUNuRCxRQUFJLENBQUNHLEtBQU07QUFHWCxVQUFNSSxnQkFBZ0JsQztBQUN0QixVQUFNbUMsY0FBY25DLE1BQU1vQyxPQUFPLENBQUNKLE1BQU1BLEVBQUVDLE9BQU9OLFdBQVc7QUFDNUQsVUFBTVUsWUFBWUYsWUFDZkMsT0FBTyxDQUFDSixNQUFNQSxFQUFFTSxhQUFhYixZQUFZRyxXQUFXLEVBQ3BEYixLQUFLLENBQUNDLEdBQUdDLE1BQU1ELEVBQUV1QixpQkFBaUJ0QixFQUFFc0IsY0FBYztBQUNyREYsY0FBVUcsT0FBT2YsWUFBWUksT0FBTyxHQUFHO0FBQUEsTUFDckMsR0FBR0M7QUFBQUEsTUFDSFEsVUFBVWIsWUFBWUc7QUFBQUEsTUFDdEJXLGdCQUFnQmQsWUFBWUk7QUFBQUEsSUFDOUIsQ0FBQztBQUNELFVBQU1ZLE9BQU9OLFlBQVlDLE9BQU8sQ0FBQ0osTUFBTUEsRUFBRU0sYUFBYWIsWUFBWUcsV0FBVztBQUM3RTNCLGFBQVMsQ0FBQyxHQUFHd0MsTUFBTSxHQUFHSixTQUFTLENBQUM7QUFFaEMsUUFBSTtBQUNGLFlBQU05RCxJQUFJbUUsU0FBUzdELFNBQVM4QyxhQUFhO0FBQUEsUUFDdkNXLFVBQVViLFlBQVlHO0FBQUFBLFFBQ3RCVyxnQkFBZ0JkLFlBQVlJO0FBQUFBLE1BQzlCLENBQUM7QUFDRCxZQUFNbkIsS0FBSztBQUFBLElBQ2IsU0FBU1MsS0FBSztBQUNabEIsZUFBU2lDLGFBQWE7QUFDdEI3QixlQUFTYyxlQUFlM0MsV0FBVzJDLElBQUlDLFVBQVUsK0JBQStCO0FBQUEsSUFDbEY7QUFBQSxFQUNGO0FBRUEsaUJBQWV1QixjQUFjQyxTQUFpQkMsU0FBaUJDLFVBQWtCO0FBQy9FLFFBQUksQ0FBQ2pFLFFBQVM7QUFDZCxRQUFJO0FBQ0YsWUFBTU4sSUFBSXdFLFdBQVdsRSxTQUFTLEVBQUVnRSxTQUFTQyxVQUFVUixVQUFVTSxRQUFRLENBQUM7QUFDdEUsWUFBTWxDLEtBQUs7QUFBQSxJQUNiLFNBQVNTLEtBQUs7QUFDWmQsZUFBU2MsZUFBZTNDLFdBQVcyQyxJQUFJQyxVQUFVLDRCQUE0QjtBQUFBLElBQy9FO0FBQUEsRUFDRjtBQUVBLGlCQUFlNEIsaUJBQWlCO0FBQzlCLFFBQUksQ0FBQ25FLFFBQVM7QUFDZCxVQUFNb0UsT0FBT0MsT0FBT0MsT0FBTyxvQkFBb0I7QUFDL0MsUUFBSSxDQUFDRixRQUFRLENBQUNBLEtBQUtHLEtBQUssRUFBRztBQUMzQixRQUFJO0FBQ0YsWUFBTTdFLElBQUk4RSxZQUFZeEUsU0FBUyxFQUFFb0UsTUFBTUEsS0FBS0csS0FBSyxFQUFFLENBQUM7QUFDcEQsWUFBTTFDLEtBQUs7QUFBQSxJQUNiLFNBQVNTLEtBQUs7QUFDWmQsZUFBU2MsZUFBZTNDLFdBQVcyQyxJQUFJQyxVQUFVLDBCQUEwQjtBQUFBLElBQzdFO0FBQUEsRUFDRjtBQUVBLGlCQUFla0Msa0JBQWtCVixTQUFpQkssTUFBYztBQUM5RCxRQUFJLENBQUNwRSxRQUFTO0FBQ2QsUUFBSTtBQUNGLFlBQU1OLElBQUlnRixZQUFZMUUsU0FBUytELFNBQVMsRUFBRUssS0FBSyxDQUFDO0FBQ2hELFlBQU12QyxLQUFLO0FBQUEsSUFDYixTQUFTUyxLQUFLO0FBQ1pkLGVBQVNjLGVBQWUzQyxXQUFXMkMsSUFBSUMsVUFBVSwrQkFBK0I7QUFBQSxJQUNsRjtBQUFBLEVBQ0Y7QUFFQSxpQkFBZW9DLGtCQUFrQlosU0FBaUI7QUFDaEQsUUFBSSxDQUFDL0QsUUFBUztBQUNkLFFBQUksQ0FBQ3FFLE9BQU9PLFFBQVEsb0JBQW9CLEVBQUc7QUFDM0MsUUFBSTtBQUNGLFlBQU1sRixJQUFJbUYsWUFBWTdFLFNBQVMrRCxPQUFPO0FBQ3RDLFlBQU1sQyxLQUFLO0FBQUEsSUFDYixTQUFTUyxLQUFLO0FBQ1pkLGVBQVNjLGVBQWUzQyxXQUFXMkMsSUFBSUMsVUFBVSwwQkFBMEI7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFFQSxRQUFNdUMsZUFBZTNELE1BQU0rQixLQUFLLENBQUNDLE1BQU1BLEVBQUVDLE9BQU8zQixjQUFjLEtBQUs7QUFFbkUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLFlBQU8sV0FBVSxnQkFDaEI7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxvQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsUUFDeEIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQjtBQUFBO0FBQUEsVUFBV3pCO0FBQUFBLGFBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxXQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSxnQkFDYmE7QUFBQUEsZ0JBQU1rRTtBQUFBQSxVQUFNO0FBQUEsVUFBR2xFLE1BQU1lO0FBQUFBLFVBQUs7QUFBQSxhQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU1aLFNBQVMsY0FBYztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBRjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLFdBQVUsYUFBWSxTQUFTRCxRQUFPLHFCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxJQUVDUSxTQUNDLHVCQUFDLFNBQUksV0FBVSxnQkFDWkE7QUFBQUE7QUFBQUEsTUFDRCx1QkFBQyxZQUFPLFdBQVUsZUFBYyxTQUFTLE1BQU1DLFNBQVMsSUFBSSxHQUFFLGlCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBR0RILFVBQ0MsdUJBQUMsT0FBRSxXQUFVLGdCQUFlLHFDQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlELElBRWpELHVCQUFDLG1CQUFnQixXQUFXcUIsZUFDMUIsaUNBQUMsU0FBSSxXQUFVLGlCQUNaekI7QUFBQUEsYUFBTytEO0FBQUFBLFFBQUksQ0FBQ0MsVUFDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUM7QUFBQSxZQUNBLE9BQU85RCxNQUNKb0MsT0FBTyxDQUFDSixNQUFNQSxFQUFFTSxhQUFhd0IsTUFBTTdCLEVBQUUsRUFDckNsQixLQUFLLENBQUNDLEdBQUdDLE1BQU1ELEVBQUV1QixpQkFBaUJ0QixFQUFFc0IsY0FBYztBQUFBLFlBQ3JELFVBQVUsQ0FBQyxDQUFDL0I7QUFBQUEsWUFDWixZQUFZRDtBQUFBQSxZQUNaLFdBQVdvQztBQUFBQSxZQUNYLGVBQWVXO0FBQUFBLFlBQ2YsZUFBZUU7QUFBQUE7QUFBQUEsVUFUVk0sTUFBTTdCO0FBQUFBLFVBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVtQztBQUFBLE1BRXBDO0FBQUEsTUFDQXpCLFlBQ0MsdUJBQUMsWUFBTyxXQUFVLG9CQUFtQixTQUFTd0MsZ0JBQWUsc0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkEsS0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLElBR0RXLGdCQUFnQjlFLFdBQ2Y7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxNQUFNOEU7QUFBQUEsUUFDTixVQUFVLENBQUMsQ0FBQ25EO0FBQUFBLFFBQ1osU0FBUyxNQUFNRCxrQkFBa0IsSUFBSTtBQUFBLFFBQ3JDLFdBQVcsQ0FBQ3dELFlBQVk7QUFDdEI5RCxtQkFBUyxDQUFDK0QsU0FBU0EsS0FBS0gsSUFBSSxDQUFDN0IsTUFBT0EsRUFBRUMsT0FBTzhCLFFBQVE5QixLQUFLOEIsVUFBVS9CLENBQUUsQ0FBQztBQUFBLFFBQ3pFO0FBQUEsUUFDQSxXQUFXLENBQUNpQyxXQUFXO0FBQ3JCaEUsbUJBQVMsQ0FBQytELFNBQVNBLEtBQUs1QixPQUFPLENBQUNKLE1BQU1BLEVBQUVDLE9BQU9nQyxNQUFNLENBQUM7QUFDdEQxRCw0QkFBa0IsSUFBSTtBQUFBLFFBQ3hCO0FBQUE7QUFBQSxNQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVdJO0FBQUEsT0F2RVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBFQTtBQUVKO0FBQUNkLEdBaE5lRCxXQUFTO0FBQUEsVUFDdUJmLFNBQzdCSCxXQUFXO0FBQUE7QUFBQSxLQUZka0I7QUFBUyxJQUFBMEU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRHJhZ0Ryb3BDb250ZXh0IiwidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwiYXBpIiwiQXBpRXJyb3IiLCJ1c2VBdXRoIiwiU3RhZ2VDb2x1bW4iLCJDYXJkTW9kYWwiLCJmZXRjaEFsbENhcmRzIiwiYm9hcmRJZCIsImxpbWl0Iiwib2Zmc2V0IiwiYWxsIiwicGFnZSIsImxpc3RDYXJkcyIsInB1c2giLCJpdGVtcyIsImxlbmd0aCIsInBhZ2luYXRpb24iLCJ0b3RhbCIsIkJvYXJkUGFnZSIsIl9zIiwidXNlciIsInNldEJvYXJkSWQiLCJsb2dvdXQiLCJuYXZpZ2F0ZSIsInN0YWdlcyIsInNldFN0YWdlcyIsImNhcmRzIiwic2V0Q2FyZHMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJzZWxlY3RlZENhcmRJZCIsInNldFNlbGVjdGVkQ2FyZElkIiwiY2FuV3JpdGUiLCJyb2xlIiwibG9hZCIsInN0YWdlc0RhdGEiLCJjYXJkc0RhdGEiLCJQcm9taXNlIiwibGlzdFN0YWdlcyIsInNvcnQiLCJhIiwiYiIsIm9yZGVyX2luZGV4IiwiZXJyIiwibWVzc2FnZSIsIkVycm9yIiwicmVwbGFjZSIsImhhbmRsZURyYWdFbmQiLCJyZXN1bHQiLCJkZXN0aW5hdGlvbiIsInNvdXJjZSIsImRyYWdnYWJsZUlkIiwiZHJvcHBhYmxlSWQiLCJpbmRleCIsImNhcmQiLCJmaW5kIiwiYyIsImlkIiwicHJldmlvdXNDYXJkcyIsIndpdGhvdXRDYXJkIiwiZmlsdGVyIiwiZGVzdENhcmRzIiwic3RhZ2VfaWQiLCJwb3NpdGlvbl9pbmRleCIsInNwbGljZSIsInJlc3QiLCJtb3ZlQ2FyZCIsImhhbmRsZUFkZENhcmQiLCJzdGFnZUlkIiwiY29tcGFueSIsInBvc2l0aW9uIiwiY3JlYXRlQ2FyZCIsImhhbmRsZUFkZFN0YWdlIiwibmFtZSIsIndpbmRvdyIsInByb21wdCIsInRyaW0iLCJjcmVhdGVTdGFnZSIsImhhbmRsZVJlbmFtZVN0YWdlIiwidXBkYXRlU3RhZ2UiLCJoYW5kbGVEZWxldGVTdGFnZSIsImNvbmZpcm0iLCJkZWxldGVTdGFnZSIsInNlbGVjdGVkQ2FyZCIsImVtYWlsIiwibWFwIiwic3RhZ2UiLCJ1cGRhdGVkIiwicHJldiIsImNhcmRJZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJvYXJkUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiDQhtC90YHRgtGA0YPQvNC10L3RgjogQ2xhdWRlXG4gKiDQl9Cw0YHRgtC+0YHRg9Cy0LDQvdC90Y86INCa0LDQvdCx0LDQvS3QtNC+0YjQutCwIOKAlCDQutC+0LvQvtC90LrQuC3QtdGC0LDQv9C4IChHRVQgLi4uL3N0YWdlcykg0YLQsCDQutCw0YDRgtC60LhcbiAqIChHRVQgLi4uL2NhcmRzINC3INC00L7Qs9C+0YDRgtCw0L3QvdGP0Lwg0YHRgtC+0YDRltC90L7QuiksIGRyYWctYW5kLWRyb3Ag0LzRltC2INC10YLQsNC/0LDQvNC4XG4gKiAoUE9TVCAuLi4vY2FyZHMve2lkfS9tb3ZlKSwg0LrQtdGA0YPQstCw0L3QvdGPINC10YLQsNC/0LDQvNC4INC5INC60LDRgNGC0LrQsNC80Lg7INC00L7RgdGC0YPQvyDQvdCwXG4gKiDQt9Cw0L/QuNGBINC+0LHQvNC10LbQtdC90L4g0L3QsCBVSSDRgtCw0Log0YHQsNC80L4sINGP0LogcmVxdWlyZV9ib2FyZF9hY2Nlc3MvQ2FuZGlkYXRlT3JBZG1pblxuICog0L7QsdC80LXQttGD0Y7RgtGMINC50L7Qs9C+INC90LAg0LHQtdC60LXQvdC00ZYgKGF1dGgucHkpLlxuICog0JLQtdGA0LjRhNGW0LrQsNGG0ZbRjzog0J/QtdGA0LXQstGW0YDQtdC90L4g0YLQuNC/0LggKHRzYyAtYikg0ZYg0L/RgNC+0LTQsNC60YjQvS3QsdGW0LvQtCAodml0ZSBidWlsZCkg0LHQtdC3XG4gKiDQv9C+0LzQuNC70L7Qujsg0YDRg9GH0L3QuNC5INC/0YDQvtCz0ZbQvSDQv9GA0L7RgtC4INC20LjQstC+0LPQviBBUEkgKNC3IGRvY2tlciBjb21wb3NlKSDQvdC1XG4gKiDQstC40LrQvtC90YPQstCw0LLRgdGPINCyINGG0ZbQuSDRgdC10YHRltGXIOKAlCDQv9C10YDQtdCy0ZbRgNGC0LUg0LLRhdGW0LQv0LTQvtGI0LrRgy9kcmFnLWFuZC1kcm9wINC70L7QutCw0LvRjNC90L4uXG4gKi9cblxuaW1wb3J0IHsgRHJhZ0Ryb3BDb250ZXh0LCB0eXBlIERyb3BSZXN1bHQgfSBmcm9tIFwiQGhlbGxvLXBhbmdlYS9kbmRcIjtcbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBhcGksIEFwaUVycm9yIH0gZnJvbSBcIi4uL2FwaS9jbGllbnRcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vY29udGV4dC9BdXRoQ29udGV4dFwiO1xuaW1wb3J0IHR5cGUgeyBDYXJkT3V0LCBTdGFnZU91dCB9IGZyb20gXCIuLi9hcGkvdHlwZXNcIjtcbmltcG9ydCB7IFN0YWdlQ29sdW1uIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvU3RhZ2VDb2x1bW5cIjtcbmltcG9ydCB7IENhcmRNb2RhbCB9IGZyb20gXCIuLi9jb21wb25lbnRzL0NhcmRNb2RhbFwiO1xuXG5hc3luYyBmdW5jdGlvbiBmZXRjaEFsbENhcmRzKGJvYXJkSWQ6IHN0cmluZyk6IFByb21pc2U8Q2FyZE91dFtdPiB7XG4gIGNvbnN0IGxpbWl0ID0gMTAwO1xuICBsZXQgb2Zmc2V0ID0gMDtcbiAgY29uc3QgYWxsOiBDYXJkT3V0W10gPSBbXTtcbiAgLy8g0JTQvtGI0LrQsCDRgNC+0LfRgNCw0YXQvtCy0LDQvdCwINC90LAgfjEwMCDQutCw0YDRgtC+0LogKGFwaS1kZXNpZ24ubWQpLCDQsNC70LUg0L3QsCDQstC40L/QsNC00L7QulxuICAvLyDQsdGW0LvRjNGI0L7Qs9C+INC+0LHRgdGP0LPRgyDQtNC+0LLQsNC90YLQsNC20YPRlNC80L4g0YHRgtC+0YDRltC90LrQsNC80LguXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zdGFudC1jb25kaXRpb25cbiAgd2hpbGUgKHRydWUpIHtcbiAgICBjb25zdCBwYWdlID0gYXdhaXQgYXBpLmxpc3RDYXJkcyhib2FyZElkLCBsaW1pdCwgb2Zmc2V0KTtcbiAgICBhbGwucHVzaCguLi5wYWdlLml0ZW1zKTtcbiAgICBpZiAoYWxsLmxlbmd0aCA+PSBwYWdlLnBhZ2luYXRpb24udG90YWwgfHwgcGFnZS5pdGVtcy5sZW5ndGggPT09IDApIGJyZWFrO1xuICAgIG9mZnNldCArPSBsaW1pdDtcbiAgfVxuICByZXR1cm4gYWxsO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQm9hcmRQYWdlKCkge1xuICBjb25zdCB7IHVzZXIsIGJvYXJkSWQsIHNldEJvYXJkSWQsIGxvZ291dCB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgY29uc3QgW3N0YWdlcywgc2V0U3RhZ2VzXSA9IHVzZVN0YXRlPFN0YWdlT3V0W10+KFtdKTtcbiAgY29uc3QgW2NhcmRzLCBzZXRDYXJkc10gPSB1c2VTdGF0ZTxDYXJkT3V0W10+KFtdKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtzZWxlY3RlZENhcmRJZCwgc2V0U2VsZWN0ZWRDYXJkSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgY2FuV3JpdGUgPSB1c2VyPy5yb2xlID09PSBcImNhbmRpZGF0ZVwiIHx8IHVzZXI/LnJvbGUgPT09IFwiYWRtaW5cIjtcblxuICBjb25zdCBsb2FkID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGlmICghYm9hcmRJZCkgcmV0dXJuO1xuICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IFtzdGFnZXNEYXRhLCBjYXJkc0RhdGFdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICBhcGkubGlzdFN0YWdlcyhib2FyZElkKSxcbiAgICAgICAgZmV0Y2hBbGxDYXJkcyhib2FyZElkKSxcbiAgICAgIF0pO1xuICAgICAgc2V0U3RhZ2VzKFsuLi5zdGFnZXNEYXRhXS5zb3J0KChhLCBiKSA9PiBhLm9yZGVyX2luZGV4IC0gYi5vcmRlcl9pbmRleCkpO1xuICAgICAgc2V0Q2FyZHMoY2FyZHNEYXRhKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBBcGlFcnJvcikge1xuICAgICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCLQndC1INCy0LTQsNC70L7RgdGPINC30LDQstCw0L3RgtCw0LbQuNGC0Lgg0LTQvtGI0LrRg1wiKTtcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9LCBbYm9hcmRJZF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbG9hZCgpO1xuICB9LCBbbG9hZF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFib2FyZElkKSBuYXZpZ2F0ZShcIi9ib2FyZC9zZXR1cFwiLCB7IHJlcGxhY2U6IHRydWUgfSk7XG4gIH0sIFtib2FyZElkLCBuYXZpZ2F0ZV0pO1xuXG4gIGlmICghYm9hcmRJZCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlRHJhZ0VuZChyZXN1bHQ6IERyb3BSZXN1bHQpIHtcbiAgICBpZiAoIWJvYXJkSWQgfHwgIWNhbldyaXRlKSByZXR1cm47XG4gICAgY29uc3QgeyBkZXN0aW5hdGlvbiwgc291cmNlLCBkcmFnZ2FibGVJZCB9ID0gcmVzdWx0O1xuICAgIGlmICghZGVzdGluYXRpb24pIHJldHVybjtcbiAgICBpZiAoXG4gICAgICBkZXN0aW5hdGlvbi5kcm9wcGFibGVJZCA9PT0gc291cmNlLmRyb3BwYWJsZUlkICYmXG4gICAgICBkZXN0aW5hdGlvbi5pbmRleCA9PT0gc291cmNlLmluZGV4XG4gICAgKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgY2FyZCA9IGNhcmRzLmZpbmQoKGMpID0+IGMuaWQgPT09IGRyYWdnYWJsZUlkKTtcbiAgICBpZiAoIWNhcmQpIHJldHVybjtcblxuICAgIC8vINCe0L/RgtC40LzRltGB0YLQuNGH0L3QtSDQvtC90L7QstC70LXQvdC90Y86INC/0LXRgNC10L3QvtGB0LjQvNC+INC60LDRgNGC0LrRgyDQu9C+0LrQsNC70YzQvdC+INC+0LTRgNCw0LfRgy5cbiAgICBjb25zdCBwcmV2aW91c0NhcmRzID0gY2FyZHM7XG4gICAgY29uc3Qgd2l0aG91dENhcmQgPSBjYXJkcy5maWx0ZXIoKGMpID0+IGMuaWQgIT09IGRyYWdnYWJsZUlkKTtcbiAgICBjb25zdCBkZXN0Q2FyZHMgPSB3aXRob3V0Q2FyZFxuICAgICAgLmZpbHRlcigoYykgPT4gYy5zdGFnZV9pZCA9PT0gZGVzdGluYXRpb24uZHJvcHBhYmxlSWQpXG4gICAgICAuc29ydCgoYSwgYikgPT4gYS5wb3NpdGlvbl9pbmRleCAtIGIucG9zaXRpb25faW5kZXgpO1xuICAgIGRlc3RDYXJkcy5zcGxpY2UoZGVzdGluYXRpb24uaW5kZXgsIDAsIHtcbiAgICAgIC4uLmNhcmQsXG4gICAgICBzdGFnZV9pZDogZGVzdGluYXRpb24uZHJvcHBhYmxlSWQsXG4gICAgICBwb3NpdGlvbl9pbmRleDogZGVzdGluYXRpb24uaW5kZXgsXG4gICAgfSk7XG4gICAgY29uc3QgcmVzdCA9IHdpdGhvdXRDYXJkLmZpbHRlcigoYykgPT4gYy5zdGFnZV9pZCAhPT0gZGVzdGluYXRpb24uZHJvcHBhYmxlSWQpO1xuICAgIHNldENhcmRzKFsuLi5yZXN0LCAuLi5kZXN0Q2FyZHNdKTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBhcGkubW92ZUNhcmQoYm9hcmRJZCwgZHJhZ2dhYmxlSWQsIHtcbiAgICAgICAgc3RhZ2VfaWQ6IGRlc3RpbmF0aW9uLmRyb3BwYWJsZUlkLFxuICAgICAgICBwb3NpdGlvbl9pbmRleDogZGVzdGluYXRpb24uaW5kZXgsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGxvYWQoKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldENhcmRzKHByZXZpb3VzQ2FyZHMpO1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwi0J3QtSDQstC00LDQu9C+0YHRjyDQv9C10YDQtdC80ZbRgdGC0LjRgtC4INC60LDRgNGC0LrRg1wiKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVBZGRDYXJkKHN0YWdlSWQ6IHN0cmluZywgY29tcGFueTogc3RyaW5nLCBwb3NpdGlvbjogc3RyaW5nKSB7XG4gICAgaWYgKCFib2FyZElkKSByZXR1cm47XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGFwaS5jcmVhdGVDYXJkKGJvYXJkSWQsIHsgY29tcGFueSwgcG9zaXRpb24sIHN0YWdlX2lkOiBzdGFnZUlkIH0pO1xuICAgICAgYXdhaXQgbG9hZCgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwi0J3QtSDQstC00LDQu9C+0YHRjyDRgdGC0LLQvtGA0LjRgtC4INC60LDRgNGC0LrRg1wiKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVBZGRTdGFnZSgpIHtcbiAgICBpZiAoIWJvYXJkSWQpIHJldHVybjtcbiAgICBjb25zdCBuYW1lID0gd2luZG93LnByb21wdChcItCd0LDQt9Cy0LAg0L3QvtCy0L7Qs9C+INC10YLQsNC/0YNcIik7XG4gICAgaWYgKCFuYW1lIHx8ICFuYW1lLnRyaW0oKSkgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBhcGkuY3JlYXRlU3RhZ2UoYm9hcmRJZCwgeyBuYW1lOiBuYW1lLnRyaW0oKSB9KTtcbiAgICAgIGF3YWl0IGxvYWQoKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEFwaUVycm9yID8gZXJyLm1lc3NhZ2UgOiBcItCd0LUg0LLQtNCw0LvQvtGB0Y8g0YHRgtCy0L7RgNC40YLQuCDQtdGC0LDQv1wiKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVSZW5hbWVTdGFnZShzdGFnZUlkOiBzdHJpbmcsIG5hbWU6IHN0cmluZykge1xuICAgIGlmICghYm9hcmRJZCkgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBhcGkudXBkYXRlU3RhZ2UoYm9hcmRJZCwgc3RhZ2VJZCwgeyBuYW1lIH0pO1xuICAgICAgYXdhaXQgbG9hZCgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwi0J3QtSDQstC00LDQu9C+0YHRjyDQv9C10YDQtdC50LzQtdC90YPQstCw0YLQuCDQtdGC0LDQv1wiKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVEZWxldGVTdGFnZShzdGFnZUlkOiBzdHJpbmcpIHtcbiAgICBpZiAoIWJvYXJkSWQpIHJldHVybjtcbiAgICBpZiAoIXdpbmRvdy5jb25maXJtKFwi0JLQuNC00LDQu9C40YLQuCDRhtC10Lkg0LXRgtCw0L8/XCIpKSByZXR1cm47XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGFwaS5kZWxldGVTdGFnZShib2FyZElkLCBzdGFnZUlkKTtcbiAgICAgIGF3YWl0IGxvYWQoKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEFwaUVycm9yID8gZXJyLm1lc3NhZ2UgOiBcItCd0LUg0LLQtNCw0LvQvtGB0Y8g0LLQuNC00LDQu9C40YLQuCDQtdGC0LDQv1wiKTtcbiAgICB9XG4gIH1cblxuICBjb25zdCBzZWxlY3RlZENhcmQgPSBjYXJkcy5maW5kKChjKSA9PiBjLmlkID09PSBzZWxlY3RlZENhcmRJZCkgPz8gbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9hcmQtcGFnZVwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJib2FyZC10b3BiYXJcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDE+VGVjaCBJbnRlcnZpZXcgQm9hcmQ8L2gxPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvYXJkLWlkLWhpbnRcIj5ib2FyZF9pZDoge2JvYXJkSWR9PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib2FyZC10b3BiYXItYWN0aW9uc1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImN1cnJlbnQtdXNlclwiPlxuICAgICAgICAgICAge3VzZXI/LmVtYWlsfSAoe3VzZXI/LnJvbGV9KVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzZWNvbmRhcnlcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoXCIvYm9hcmQvc2V0dXBcIil9XG4gICAgICAgICAgPlxuICAgICAgICAgICAg0JfQvNGW0L3QuNGC0Lgg0LTQvtGI0LrRg1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwic2Vjb25kYXJ5XCIgb25DbGljaz17bG9nb3V0fT5cbiAgICAgICAgICAgINCS0LjQudGC0LhcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAge2Vycm9yICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiYW5uZXItZXJyb3JcIj5cbiAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJpY29uLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldEVycm9yKG51bGwpfT5cbiAgICAgICAgICAgIOKclVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJib2FyZC1zdGF0dXNcIj7Ql9Cw0LLQsNC90YLQsNC20LXQvdC90Y8g0LTQvtGI0LrQuC4uLjwvcD5cbiAgICAgICkgOiAoXG4gICAgICAgIDxEcmFnRHJvcENvbnRleHQgb25EcmFnRW5kPXtoYW5kbGVEcmFnRW5kfT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvYXJkLWNvbHVtbnNcIj5cbiAgICAgICAgICAgIHtzdGFnZXMubWFwKChzdGFnZSkgPT4gKFxuICAgICAgICAgICAgICA8U3RhZ2VDb2x1bW5cbiAgICAgICAgICAgICAgICBrZXk9e3N0YWdlLmlkfVxuICAgICAgICAgICAgICAgIHN0YWdlPXtzdGFnZX1cbiAgICAgICAgICAgICAgICBjYXJkcz17Y2FyZHNcbiAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKGMpID0+IGMuc3RhZ2VfaWQgPT09IHN0YWdlLmlkKVxuICAgICAgICAgICAgICAgICAgLnNvcnQoKGEsIGIpID0+IGEucG9zaXRpb25faW5kZXggLSBiLnBvc2l0aW9uX2luZGV4KX1cbiAgICAgICAgICAgICAgICBjYW5Xcml0ZT17ISFjYW5Xcml0ZX1cbiAgICAgICAgICAgICAgICBvbk9wZW5DYXJkPXtzZXRTZWxlY3RlZENhcmRJZH1cbiAgICAgICAgICAgICAgICBvbkFkZENhcmQ9e2hhbmRsZUFkZENhcmR9XG4gICAgICAgICAgICAgICAgb25SZW5hbWVTdGFnZT17aGFuZGxlUmVuYW1lU3RhZ2V9XG4gICAgICAgICAgICAgICAgb25EZWxldGVTdGFnZT17aGFuZGxlRGVsZXRlU3RhZ2V9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICAgIHtjYW5Xcml0ZSAmJiAoXG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYWRkLXN0YWdlLWJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZUFkZFN0YWdlfT5cbiAgICAgICAgICAgICAgICArINCV0YLQsNC/XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9EcmFnRHJvcENvbnRleHQ+XG4gICAgICApfVxuXG4gICAgICB7c2VsZWN0ZWRDYXJkICYmIGJvYXJkSWQgJiYgKFxuICAgICAgICA8Q2FyZE1vZGFsXG4gICAgICAgICAgYm9hcmRJZD17Ym9hcmRJZH1cbiAgICAgICAgICBjYXJkPXtzZWxlY3RlZENhcmR9XG4gICAgICAgICAgY2FuV3JpdGU9eyEhY2FuV3JpdGV9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWRDYXJkSWQobnVsbCl9XG4gICAgICAgICAgb25VcGRhdGVkPXsodXBkYXRlZCkgPT4ge1xuICAgICAgICAgICAgc2V0Q2FyZHMoKHByZXYpID0+IHByZXYubWFwKChjKSA9PiAoYy5pZCA9PT0gdXBkYXRlZC5pZCA/IHVwZGF0ZWQgOiBjKSkpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25EZWxldGVkPXsoY2FyZElkKSA9PiB7XG4gICAgICAgICAgICBzZXRDYXJkcygocHJldikgPT4gcHJldi5maWx0ZXIoKGMpID0+IGMuaWQgIT09IGNhcmRJZCkpO1xuICAgICAgICAgICAgc2V0U2VsZWN0ZWRDYXJkSWQobnVsbCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9vbGVrc2lpdm9saWsvRG9jdW1lbnRzL0dpdEh1Yi9Nb25rZXktQnVzaW5lc3MtcHJvamVjdC9zcmMvZnJvbnRlbmQvc3JjL3BhZ2VzL0JvYXJkUGFnZS50c3gifQ==