import {
  require_react
} from "/node_modules/.vite/deps/chunk-I4MZPW7S.js?v=720534a3";
export default require_react();
//# sourceMappingURL=react.js.map
