import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoginPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b39cee6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=2b39cee6"; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=8b960ccb";
import { useAuth } from "/src/context/AuthContext.tsx";
import { ApiError } from "/src/api/client.ts";
export function LoginPage() {
  _s();
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login({ email, password });
      navigate("/board");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося увійти");
    } finally {
      setLoading(false);
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-screen", children: /* @__PURE__ */ jsxDEV("form", { className: "auth-card", onSubmit, children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Tech Interview Board" }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
      lineNumber: 57,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-subtitle", children: "Увійдіть у свій обліковий запис" }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
      lineNumber: 58,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Email",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "email",
          value: email,
          onChange: (e) => setEmail(e.target.value),
          required: true,
          autoComplete: "email"
        },
        void 0,
        false,
        {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
          lineNumber: 61,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
      lineNumber: 59,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Пароль",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "password",
          value: password,
          onChange: (e) => setPassword(e.target.value),
          required: true,
          autoComplete: "current-password"
        },
        void 0,
        false,
        {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
          lineNumber: 71,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
      lineNumber: 69,
      columnNumber: 9
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "form-error", children: error }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
      lineNumber: 79,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", disabled: loading, children: loading ? "Вхід..." : "Увійти" }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
      lineNumber: 80,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-switch", children: [
      "Немає акаунту? ",
      /* @__PURE__ */ jsxDEV(Link, { to: "/register", children: "Зареєструватися" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
        lineNumber: 84,
        columnNumber: 26
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
      lineNumber: 83,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
    lineNumber: 56,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx",
    lineNumber: 55,
    columnNumber: 5
  }, this);
}
_s(LoginPage, "6RZqrx2uHbW/ityX+zHAlGzfDdk=", false, function() {
  return [useAuth, useNavigate];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/LoginPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNROzs7Ozs7Ozs7Ozs7Ozs7OztBQTlCUixTQUFvQkEsZ0JBQWdCO0FBQ3BDLFNBQVNDLE1BQU1DLG1CQUFtQjtBQUNsQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUVsQixnQkFBU0MsWUFBWTtBQUFBQyxLQUFBO0FBQzFCLFFBQU0sRUFBRUMsTUFBTSxJQUFJSixRQUFRO0FBQzFCLFFBQU1LLFdBQVdOLFlBQVk7QUFDN0IsUUFBTSxDQUFDTyxPQUFPQyxRQUFRLElBQUlWLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNXLFVBQVVDLFdBQVcsSUFBSVosU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2EsT0FBT0MsUUFBUSxJQUFJZCxTQUF3QixJQUFJO0FBQ3RELFFBQU0sQ0FBQ2UsU0FBU0MsVUFBVSxJQUFJaEIsU0FBUyxLQUFLO0FBRTVDLGlCQUFlaUIsU0FBU0MsR0FBYztBQUNwQ0EsTUFBRUMsZUFBZTtBQUNqQkwsYUFBUyxJQUFJO0FBQ2JFLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNVCxNQUFNLEVBQUVFLE9BQU9FLFNBQVMsQ0FBQztBQUMvQkgsZUFBUyxRQUFRO0FBQUEsSUFDbkIsU0FBU1ksS0FBSztBQUNaTixlQUFTTSxlQUFlaEIsV0FBV2dCLElBQUlDLFVBQVUsbUJBQW1CO0FBQUEsSUFDdEUsVUFBQztBQUNDTCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZUFDYixpQ0FBQyxVQUFLLFdBQVUsYUFBWSxVQUMxQjtBQUFBLDJCQUFDLFFBQUcsb0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QjtBQUFBLElBQ3hCLHVCQUFDLE9BQUUsV0FBVSxpQkFBZ0IsK0NBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQ7QUFBQSxJQUM1RCx1QkFBQyxXQUFLO0FBQUE7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPUDtBQUFBQSxVQUNQLFVBQVUsQ0FBQ1MsTUFBTVIsU0FBU1EsRUFBRUksT0FBT0MsS0FBSztBQUFBLFVBQ3hDO0FBQUEsVUFDQSxjQUFhO0FBQUE7QUFBQSxRQUxmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtzQjtBQUFBLFNBUHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsV0FBSztBQUFBO0FBQUEsTUFFSjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsT0FBT1o7QUFBQUEsVUFDUCxVQUFVLENBQUNPLE1BQU1OLFlBQVlNLEVBQUVJLE9BQU9DLEtBQUs7QUFBQSxVQUMzQztBQUFBLFVBQ0EsY0FBYTtBQUFBO0FBQUEsUUFMZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLaUM7QUFBQSxTQVBuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNDVixTQUFTLHVCQUFDLE9BQUUsV0FBVSxjQUFjQSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQztBQUFBLElBQzNDLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFVBQVVFLFNBQzdCQSxvQkFBVSxZQUFZLFlBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsT0FBRSxXQUFVLGVBQWE7QUFBQTtBQUFBLE1BQ1QsdUJBQUMsUUFBSyxJQUFHLGFBQVksK0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxTQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEJBLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQ0E7QUFFSjtBQUFDVCxHQXpEZUQsV0FBUztBQUFBLFVBQ0xGLFNBQ0RELFdBQVc7QUFBQTtBQUFBLEtBRmRHO0FBQVMsSUFBQW1CO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZU5hdmlnYXRlIiwidXNlQXV0aCIsIkFwaUVycm9yIiwiTG9naW5QYWdlIiwiX3MiLCJsb2dpbiIsIm5hdmlnYXRlIiwiZW1haWwiLCJzZXRFbWFpbCIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJlcnJvciIsInNldEVycm9yIiwibG9hZGluZyIsInNldExvYWRpbmciLCJvblN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImVyciIsIm1lc3NhZ2UiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxvZ2luUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiDQhtC90YHRgtGA0YPQvNC10L3RgjogQ2xhdWRlXG4gKiDQl9Cw0YHRgtC+0YHRg9Cy0LDQvdC90Y86INCk0L7RgNC80LAg0LLRhdC+0LTRgyDigJQg0LLQuNC60LvQuNC60LDRlCBQT1NUIC92MS9hdXRoL2xvZ2luIChhdXRoLnB5KS5cbiAqINCS0LXRgNC40YTRltC60LDRhtGW0Y86INCf0LXRgNC10LLRltGA0LXQvdC+INGC0LjQv9C4INC5INCx0ZbQu9C0OyDRgNGD0YfQvdC40Lkg0LfQsNC/0YPRgdC6INC/0YDQvtGC0Lgg0LbQuNCy0L7Qs9C+IEFQSSDQvdC1XG4gKiDQstC40LrQvtC90YPQstCw0LLRgdGPINCyINGG0ZbQuSDRgdC10YHRltGXLlxuICovXG5cbmltcG9ydCB7IEZvcm1FdmVudCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vY29udGV4dC9BdXRoQ29udGV4dFwiO1xuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tIFwiLi4vYXBpL2NsaWVudFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gTG9naW5QYWdlKCkge1xuICBjb25zdCB7IGxvZ2luIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIG9uU3VibWl0KGU6IEZvcm1FdmVudCkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRFcnJvcihudWxsKTtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBsb2dpbih7IGVtYWlsLCBwYXNzd29yZCB9KTtcbiAgICAgIG5hdmlnYXRlKFwiL2JvYXJkXCIpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwi0J3QtSDQstC00LDQu9C+0YHRjyDRg9Cy0ZbQudGC0LhcIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLXNjcmVlblwiPlxuICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiYXV0aC1jYXJkXCIgb25TdWJtaXQ9e29uU3VibWl0fT5cbiAgICAgICAgPGgxPlRlY2ggSW50ZXJ2aWV3IEJvYXJkPC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYXV0aC1zdWJ0aXRsZVwiPtCj0LLRltC50LTRltGC0Ywg0YMg0YHQstGW0Lkg0L7QsdC70ZbQutC+0LLQuNC5INC30LDQv9C40YE8L3A+XG4gICAgICAgIDxsYWJlbD5cbiAgICAgICAgICBFbWFpbFxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImVtYWlsXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8bGFiZWw+XG4gICAgICAgICAg0J/QsNGA0L7Qu9GMXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwiY3VycmVudC1wYXNzd29yZFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImZvcm0tZXJyb3JcIj57ZXJyb3J9PC9wPn1cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgIHtsb2FkaW5nID8gXCLQktGF0ZbQtC4uLlwiIDogXCLQo9Cy0ZbQudGC0LhcIn1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImF1dGgtc3dpdGNoXCI+XG4gICAgICAgICAg0J3QtdC80LDRlCDQsNC60LDRg9C90YLRgz8gPExpbmsgdG89XCIvcmVnaXN0ZXJcIj7Ql9Cw0YDQtdGU0YHRgtGA0YPQstCw0YLQuNGB0Y88L0xpbms+XG4gICAgICAgIDwvcD5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL29sZWtzaWl2b2xpay9Eb2N1bWVudHMvR2l0SHViL01vbmtleS1CdXNpbmVzcy1wcm9qZWN0L3NyYy9mcm9udGVuZC9zcmMvcGFnZXMvTG9naW5QYWdlLnRzeCJ9