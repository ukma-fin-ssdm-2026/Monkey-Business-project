import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/BoardSetupPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b39cee6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=2b39cee6"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=8b960ccb";
import { useAuth } from "/src/context/AuthContext.tsx";
export function BoardSetupPage() {
  _s();
  const { user, setBoardId, logout } = useAuth();
  const navigate = useNavigate();
  const [value, setValue] = useState("");
  const [error, setError] = useState(null);
  const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  function onSubmit(e) {
    e.preventDefault();
    const trimmed = value.trim();
    if (!UUID_RE.test(trimmed)) {
      setError("Це не схоже на UUID дошки (напр. 3fa85f64-5717-4562-b3fc-2c963f66afa6)");
      return;
    }
    setBoardId(trimmed);
    navigate("/board");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-screen", children: /* @__PURE__ */ jsxDEV("form", { className: "auth-card", onSubmit, children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Ідентифікатор дошки" }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
      lineNumber: 59,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-subtitle", children: [
      "Привіт, ",
      user?.email,
      "! API поки не має ендпоінта для отримання списку власних дошок, тому введіть ",
      /* @__PURE__ */ jsxDEV("code", { children: "board_id" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
        lineNumber: 62,
        columnNumber: 46
      }, this),
      " вручну."
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
      lineNumber: 60,
      columnNumber: 9
    }, this),
    user?.role === "candidate" ? /* @__PURE__ */ jsxDEV("p", { className: "hint", children: [
      "Якщо ви щойно зареєструвалися, ваша дошка вже створена. Знайти її ID можна в базі даних:",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
        lineNumber: 68,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("code", { children: [
        `docker compose exec db psql -U interview_board -d interview_board -c "select b.id from boards b join users u on u.id = b.owner_id where u.email = '`,
        user.email,
        `'"`
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
        lineNumber: 69,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
      lineNumber: 65,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("p", { className: "hint", children: [
      "Запитайте board_id у кандидата, що веде цю дошку (ви —",
      " ",
      user?.role === "mentor" ? "ментор" : "адміністратор",
      ")."
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
      lineNumber: 77,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "board_id",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          placeholder: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          value,
          onChange: (e) => setValue(e.target.value),
          required: true
        },
        void 0,
        false,
        {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
          lineNumber: 84,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
      lineNumber: 82,
      columnNumber: 9
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "form-error", children: error }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
      lineNumber: 92,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Відкрити дошку" }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
      lineNumber: 93,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "button", className: "link-button", onClick: logout, children: "Вийти з акаунту" }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
      lineNumber: 94,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
    lineNumber: 58,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx",
    lineNumber: 57,
    columnNumber: 5
  }, this);
}
_s(BoardSetupPage, "pRbdcxXb1Qu78EukOxMMj0Qsq+o=", false, function() {
  return [useAuth, useNavigate];
});
_c = BoardSetupPage;
var _c;
$RefreshReg$(_c, "BoardSetupPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/BoardSetupPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNROzs7Ozs7Ozs7Ozs7Ozs7OztBQTlCUixTQUFvQkEsZ0JBQWdCO0FBQ3BDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxlQUFlO0FBS2pCLGdCQUFTQyxpQkFBaUI7QUFBQUMsS0FBQTtBQUMvQixRQUFNLEVBQUVDLE1BQU1DLFlBQVlDLE9BQU8sSUFBSUwsUUFBUTtBQUM3QyxRQUFNTSxXQUFXUCxZQUFZO0FBQzdCLFFBQU0sQ0FBQ1EsT0FBT0MsUUFBUSxJQUFJVixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDVyxPQUFPQyxRQUFRLElBQUlaLFNBQXdCLElBQUk7QUFFdEQsUUFBTWEsVUFDSjtBQUVGLFdBQVNDLFNBQVNDLEdBQWM7QUFDOUJBLE1BQUVDLGVBQWU7QUFDakIsVUFBTUMsVUFBVVIsTUFBTVMsS0FBSztBQUMzQixRQUFJLENBQUNMLFFBQVFNLEtBQUtGLE9BQU8sR0FBRztBQUMxQkwsZUFBUyx3RUFBd0U7QUFDakY7QUFBQSxJQUNGO0FBQ0FOLGVBQVdXLE9BQU87QUFDbEJULGFBQVMsUUFBUTtBQUFBLEVBQ25CO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZUFDYixpQ0FBQyxVQUFLLFdBQVUsYUFBWSxVQUMxQjtBQUFBLDJCQUFDLFFBQUcsbUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QjtBQUFBLElBQ3ZCLHVCQUFDLE9BQUUsV0FBVSxpQkFBZTtBQUFBO0FBQUEsTUFDakJILE1BQU1lO0FBQUFBLE1BQU07QUFBQSxNQUNjLHVCQUFDLFVBQUssd0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjO0FBQUEsTUFBTztBQUFBLFNBRjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0NmLE1BQU1nQixTQUFTLGNBQ2QsdUJBQUMsT0FBRSxXQUFVLFFBQU07QUFBQTtBQUFBLE1BR2pCLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxVQUFJO0FBQUE7QUFBQSxRQUd5Q2hCLEtBQUtlO0FBQUFBLFFBQUs7QUFBQSxXQUh4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSxRQUFNO0FBQUE7QUFBQSxNQUNzQztBQUFBLE1BQ3REZixNQUFNZ0IsU0FBUyxXQUFXLFdBQVc7QUFBQSxNQUFnQjtBQUFBLFNBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUYsdUJBQUMsV0FBSztBQUFBO0FBQUEsTUFFSjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsYUFBWTtBQUFBLFVBQ1o7QUFBQSxVQUNBLFVBQVUsQ0FBQ04sTUFBTUwsU0FBU0ssRUFBRU8sT0FBT2IsS0FBSztBQUFBLFVBQ3hDLFVBQVE7QUFBQTtBQUFBLFFBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS1U7QUFBQSxTQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0NFLFNBQVMsdUJBQUMsT0FBRSxXQUFVLGNBQWNBLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFDM0MsdUJBQUMsWUFBTyxNQUFLLFVBQVMsOEJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0M7QUFBQSxJQUNwQyx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGVBQWMsU0FBU0osUUFBTywrQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVDQSxLQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUNBO0FBRUo7QUFBQ0gsR0FoRWVELGdCQUFjO0FBQUEsVUFDU0QsU0FDcEJELFdBQVc7QUFBQTtBQUFBLEtBRmRFO0FBQWMsSUFBQW9CO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJ1c2VBdXRoIiwiQm9hcmRTZXR1cFBhZ2UiLCJfcyIsInVzZXIiLCJzZXRCb2FyZElkIiwibG9nb3V0IiwibmF2aWdhdGUiLCJ2YWx1ZSIsInNldFZhbHVlIiwiZXJyb3IiLCJzZXRFcnJvciIsIlVVSURfUkUiLCJvblN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRyaW1tZWQiLCJ0cmltIiwidGVzdCIsImVtYWlsIiwicm9sZSIsInRhcmdldCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJvYXJkU2V0dXBQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqINCG0L3RgdGC0YDRg9C80LXQvdGCOiBDbGF1ZGVcbiAqINCX0LDRgdGC0L7RgdGD0LLQsNC90L3Rjzog0JXQutGA0LDQvSDRgNGD0YfQvdC+0LPQviDQstCy0L7QtNGDIGJvYXJkX2lkIOKAlCDQvtCx0YXRltC0INCy0ZbQtNGB0YPRgtC90YzQvtCz0L4g0LIgQVBJXG4gKiDQtdC90LTQv9C+0ZbQvdGC0LAgXCLQvNC+0Zcg0LTQvtGI0LrQuFwiICjRhNGW0LrRgdGD0ZTRgtGM0YHRjyDQsiBzcmMvYXBpL1JFQURNRS5tZCksINGA0LXQsNC70ZbQt9C+0LLQsNC90LjQuVxuICog0LvQuNGI0LUg0L3QsCDRhNGA0L7QvdGC0LXQvdC00ZYsINCx0LXQtyDQt9C80ZbQvSDQsdC10LrQtdC90LTRgy5cbiAqINCS0LXRgNC40YTRltC60LDRhtGW0Y86INCf0LXRgNC10LLRltGA0LXQvdC+INGC0LjQv9C4INC5INCx0ZbQu9C0OyDRgNC10LPRg9C70Y/RgNC90LjQuSDQstC40YDQsNC3IFVVSUQg0L/QtdGA0LXQstGW0YDQtdC90L5cbiAqINCy0YDRg9GH0L3RgyDQvdCwINC/0YDQuNC60LvQsNC00ZYg0Lcg0LTQvtC60YPQvNC10L3RgtCw0YbRltGXICgzZmE4NWY2NC01NzE3LTQ1NjItYjNmYy0yYzk2M2Y2NmFmYTYpLlxuICovXG5cbmltcG9ydCB7IEZvcm1FdmVudCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vY29udGV4dC9BdXRoQ29udGV4dFwiO1xuXG4vLyDQkdC10LrQtdC90LQg0L/QvtC60Lgg0L3QtSDQvNCw0ZQg0LXQvdC00L/QvtGW0L3RgtCwIFwi0LzQvtGXINC00L7RiNC60LhcIiAoc3JjL2FwaS9SRUFETUUubWQ6XG4vLyBcItCe0LrRgNC10LzQvtCz0L4g0LXQvdC00L/QvtGW0L3RgtCwINC00LvRjyDQvtGC0YDQuNC80LDQvdC90Y8gYm9hcmRfaWQg0L/QvtC60Lgg0L3QtdC80LDRlFwiKSwg0YLQvtC80YMgYm9hcmRfaWRcbi8vINGG0YzQvtCz0L4g0LrQvtGA0LjRgdGC0YPQstCw0YfQsCDQv9GA0L7RgdGP0YLRjCDQstCy0LXRgdGC0Lgg0L7QtNC40L0g0YDQsNC3INGWINC30LHQtdGA0ZbQs9Cw0Y7RgtGMINC70LjRiNC1INCyINCx0YDQsNGD0LfQtdGA0ZYuXG5leHBvcnQgZnVuY3Rpb24gQm9hcmRTZXR1cFBhZ2UoKSB7XG4gIGNvbnN0IHsgdXNlciwgc2V0Qm9hcmRJZCwgbG9nb3V0IH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBVVUlEX1JFID1cbiAgICAvXlswLTlhLWZdezh9LVswLTlhLWZdezR9LVswLTlhLWZdezR9LVswLTlhLWZdezR9LVswLTlhLWZdezEyfSQvaTtcblxuICBmdW5jdGlvbiBvblN1Ym1pdChlOiBGb3JtRXZlbnQpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgY29uc3QgdHJpbW1lZCA9IHZhbHVlLnRyaW0oKTtcbiAgICBpZiAoIVVVSURfUkUudGVzdCh0cmltbWVkKSkge1xuICAgICAgc2V0RXJyb3IoXCLQptC1INC90LUg0YHRhdC+0LbQtSDQvdCwIFVVSUQg0LTQvtGI0LrQuCAo0L3QsNC/0YAuIDNmYTg1ZjY0LTU3MTctNDU2Mi1iM2ZjLTJjOTYzZjY2YWZhNilcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldEJvYXJkSWQodHJpbW1lZCk7XG4gICAgbmF2aWdhdGUoXCIvYm9hcmRcIik7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1zY3JlZW5cIj5cbiAgICAgIDxmb3JtIGNsYXNzTmFtZT1cImF1dGgtY2FyZFwiIG9uU3VibWl0PXtvblN1Ym1pdH0+XG4gICAgICAgIDxoMT7QhtC00LXQvdGC0LjRhNGW0LrQsNGC0L7RgCDQtNC+0YjQutC4PC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYXV0aC1zdWJ0aXRsZVwiPlxuICAgICAgICAgINCf0YDQuNCy0ZbRgiwge3VzZXI/LmVtYWlsfSEgQVBJINC/0L7QutC4INC90LUg0LzQsNGUINC10L3QtNC/0L7RltC90YLQsCDQtNC70Y8g0L7RgtGA0LjQvNCw0L3QvdGPXG4gICAgICAgICAg0YHQv9C40YHQutGDINCy0LvQsNGB0L3QuNGFINC00L7RiNC+0LosINGC0L7QvNGDINCy0LLQtdC00ZbRgtGMIDxjb2RlPmJvYXJkX2lkPC9jb2RlPiDQstGA0YPRh9C90YMuXG4gICAgICAgIDwvcD5cbiAgICAgICAge3VzZXI/LnJvbGUgPT09IFwiY2FuZGlkYXRlXCIgPyAoXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiaGludFwiPlxuICAgICAgICAgICAg0K/QutGJ0L4g0LLQuCDRidC+0LnQvdC+INC30LDRgNC10ZTRgdGC0YDRg9Cy0LDQu9C40YHRjywg0LLQsNGI0LAg0LTQvtGI0LrQsCDQstC20LUg0YHRgtCy0L7RgNC10L3QsC4g0JfQvdCw0LnRgtC4XG4gICAgICAgICAgICDRl9GXIElEINC80L7QttC90LAg0LIg0LHQsNC30ZYg0LTQsNC90LjRhTpcbiAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgPGNvZGU+XG4gICAgICAgICAgICAgIGRvY2tlciBjb21wb3NlIGV4ZWMgZGIgcHNxbCAtVSBpbnRlcnZpZXdfYm9hcmQgLWRcbiAgICAgICAgICAgICAgaW50ZXJ2aWV3X2JvYXJkIC1jICZxdW90O3NlbGVjdCBiLmlkIGZyb20gYm9hcmRzIGIgam9pbiB1c2VycyB1XG4gICAgICAgICAgICAgIG9uIHUuaWQgPSBiLm93bmVyX2lkIHdoZXJlIHUuZW1haWwgPSAmYXBvczt7dXNlci5lbWFpbH1cbiAgICAgICAgICAgICAgJmFwb3M7JnF1b3Q7XG4gICAgICAgICAgICA8L2NvZGU+XG4gICAgICAgICAgPC9wPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhpbnRcIj5cbiAgICAgICAgICAgINCX0LDQv9C40YLQsNC50YLQtSBib2FyZF9pZCDRgyDQutCw0L3QtNC40LTQsNGC0LAsINGJ0L4g0LLQtdC00LUg0YbRjiDQtNC+0YjQutGDICjQstC4IOKAlHtcIiBcIn1cbiAgICAgICAgICAgIHt1c2VyPy5yb2xlID09PSBcIm1lbnRvclwiID8gXCLQvNC10L3RgtC+0YBcIiA6IFwi0LDQtNC80ZbQvdGW0YHRgtGA0LDRgtC+0YBcIn0pLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgKX1cbiAgICAgICAgPGxhYmVsPlxuICAgICAgICAgIGJvYXJkX2lkXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjNmYTg1ZjY0LTU3MTctNDU2Mi1iM2ZjLTJjOTYzZjY2YWZhNlwiXG4gICAgICAgICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFZhbHVlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImZvcm0tZXJyb3JcIj57ZXJyb3J9PC9wPn1cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+0JLRltC00LrRgNC40YLQuCDQtNC+0YjQutGDPC9idXR0b24+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImxpbmstYnV0dG9uXCIgb25DbGljaz17bG9nb3V0fT5cbiAgICAgICAgICDQktC40LnRgtC4INC3INCw0LrQsNGD0L3RgtGDXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvb2xla3NpaXZvbGlrL0RvY3VtZW50cy9HaXRIdWIvTW9ua2V5LUJ1c2luZXNzLXByb2plY3Qvc3JjL2Zyb250ZW5kL3NyYy9wYWdlcy9Cb2FyZFNldHVwUGFnZS50c3gifQ==