import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RegisterPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b39cee6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=2b39cee6"; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=8b960ccb";
import { useAuth } from "/src/context/AuthContext.tsx";
import { ApiError } from "/src/api/client.ts";
export function RegisterPage() {
  _s();
  const { register } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await register({ email, password, role: "candidate" });
      navigate("/board");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося зареєструватися");
    } finally {
      setLoading(false);
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-screen", children: /* @__PURE__ */ jsxDEV("form", { className: "auth-card", onSubmit, children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Tech Interview Board" }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
      lineNumber: 60,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-subtitle", children: "Реєстрація кандидата — разом з акаунтом створюється ваша дошка з чотирма стандартними етапами." }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
      lineNumber: 61,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Email",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "email",
          value: email,
          onChange: (e) => setEmail(e.target.value),
          required: true,
          autoComplete: "email"
        },
        void 0,
        false,
        {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
          lineNumber: 67,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
      lineNumber: 65,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Пароль",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "password",
          value: password,
          onChange: (e) => setPassword(e.target.value),
          required: true,
          minLength: 8,
          maxLength: 128,
          autoComplete: "new-password"
        },
        void 0,
        false,
        {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
          lineNumber: 77,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
      lineNumber: 75,
      columnNumber: 9
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "form-error", children: error }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
      lineNumber: 87,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", disabled: loading, children: loading ? "Реєстрація..." : "Зареєструватися" }, void 0, false, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
      lineNumber: 88,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-switch", children: [
      "Вже є акаунт? ",
      /* @__PURE__ */ jsxDEV(Link, { to: "/login", children: "Увійти" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
        lineNumber: 92,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
      lineNumber: 91,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
    lineNumber: 59,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx",
    lineNumber: 58,
    columnNumber: 5
  }, this);
}
_s(RegisterPage, "T40HTSEQBOKBnVLdp52f0kTvSkA=", false, function() {
  return [useAuth, useNavigate];
});
_c = RegisterPage;
var _c;
$RefreshReg$(_c, "RegisterPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/pages/RegisterPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NROzs7Ozs7Ozs7Ozs7Ozs7OztBQWhDUixTQUFvQkEsZ0JBQWdCO0FBQ3BDLFNBQVNDLE1BQU1DLG1CQUFtQjtBQUNsQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUVsQixnQkFBU0MsZUFBZTtBQUFBQyxLQUFBO0FBQzdCLFFBQU0sRUFBRUMsU0FBUyxJQUFJSixRQUFRO0FBQzdCLFFBQU1LLFdBQVdOLFlBQVk7QUFDN0IsUUFBTSxDQUFDTyxPQUFPQyxRQUFRLElBQUlWLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNXLFVBQVVDLFdBQVcsSUFBSVosU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2EsT0FBT0MsUUFBUSxJQUFJZCxTQUF3QixJQUFJO0FBQ3RELFFBQU0sQ0FBQ2UsU0FBU0MsVUFBVSxJQUFJaEIsU0FBUyxLQUFLO0FBRTVDLGlCQUFlaUIsU0FBU0MsR0FBYztBQUNwQ0EsTUFBRUMsZUFBZTtBQUNqQkwsYUFBUyxJQUFJO0FBQ2JFLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFHRixZQUFNVCxTQUFTLEVBQUVFLE9BQU9FLFVBQVVTLE1BQU0sWUFBWSxDQUFDO0FBQ3JEWixlQUFTLFFBQVE7QUFBQSxJQUNuQixTQUFTYSxLQUFLO0FBQ1pQLGVBQVNPLGVBQWVqQixXQUFXaUIsSUFBSUMsVUFBVSw0QkFBNEI7QUFBQSxJQUMvRSxVQUFDO0FBQ0NOLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxlQUNiLGlDQUFDLFVBQUssV0FBVSxhQUFZLFVBQzFCO0FBQUEsMkJBQUMsUUFBRyxvQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCO0FBQUEsSUFDeEIsdUJBQUMsT0FBRSxXQUFVLGlCQUFlLDhHQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFdBQUs7QUFBQTtBQUFBLE1BRUo7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU9QO0FBQUFBLFVBQ1AsVUFBVSxDQUFDUyxNQUFNUixTQUFTUSxFQUFFSyxPQUFPQyxLQUFLO0FBQUEsVUFDeEM7QUFBQSxVQUNBLGNBQWE7QUFBQTtBQUFBLFFBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3NCO0FBQUEsU0FQeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxXQUFLO0FBQUE7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPYjtBQUFBQSxVQUNQLFVBQVUsQ0FBQ08sTUFBTU4sWUFBWU0sRUFBRUssT0FBT0MsS0FBSztBQUFBLFVBQzNDO0FBQUEsVUFDQSxXQUFXO0FBQUEsVUFDWCxXQUFXO0FBQUEsVUFDWCxjQUFhO0FBQUE7QUFBQSxRQVBmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU82QjtBQUFBLFNBVC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBQ0NYLFNBQVMsdUJBQUMsT0FBRSxXQUFVLGNBQWNBLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFDM0MsdUJBQUMsWUFBTyxNQUFLLFVBQVMsVUFBVUUsU0FDN0JBLG9CQUFVLGtCQUFrQixxQkFEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxPQUFFLFdBQVUsZUFBYTtBQUFBO0FBQUEsTUFDVix1QkFBQyxRQUFLLElBQUcsVUFBUyxzQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLFNBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQ0EsS0FwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFDQTtBQUVKO0FBQUNULEdBaEVlRCxjQUFZO0FBQUEsVUFDTEYsU0FDSkQsV0FBVztBQUFBO0FBQUEsS0FGZEc7QUFBWSxJQUFBb0I7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJ1c2VBdXRoIiwiQXBpRXJyb3IiLCJSZWdpc3RlclBhZ2UiLCJfcyIsInJlZ2lzdGVyIiwibmF2aWdhdGUiLCJlbWFpbCIsInNldEVtYWlsIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImVycm9yIiwic2V0RXJyb3IiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsIm9uU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0Iiwicm9sZSIsImVyciIsIm1lc3NhZ2UiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlZ2lzdGVyUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiDQhtC90YHRgtGA0YPQvNC10L3RgjogQ2xhdWRlXG4gKiDQl9Cw0YHRgtC+0YHRg9Cy0LDQvdC90Y86INCk0L7RgNC80LAg0YDQtdGU0YHRgtGA0LDRhtGW0Zcg0LrQsNC90LTQuNC00LDRgtCwIOKAlCBQT1NUIC92MS9hdXRoL3JlZ2lzdGVyXG4gKiAoYXV0aC5weTsg0LHQtdC60LXQvdC0INC00L7Qt9Cy0L7Qu9GP0ZQg0LvQuNGI0LUg0YDQvtC70YwgY2FuZGlkYXRlLCDRgtC+0LzRgyDQstC40LHRltGAINGA0L7Qu9GWINCy0ZbQtNGB0YPRgtC90ZbQuSkuXG4gKiDQktC10YDQuNGE0ZbQutCw0YbRltGPOiDQn9C10YDQtdCy0ZbRgNC10L3QviDRgtC40L/QuCDQuSDQsdGW0LvQtDsg0YDRg9GH0L3QuNC5INC30LDQv9GD0YHQuiDQv9GA0L7RgtC4INC20LjQstC+0LPQviBBUEkg0L3QtVxuICog0LLQuNC60L7QvdGD0LLQsNCy0YHRjyDQsiDRhtGW0Lkg0YHQtdGB0ZbRly5cbiAqL1xuXG5pbXBvcnQgeyBGb3JtRXZlbnQsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL2NvbnRleHQvQXV0aENvbnRleHRcIjtcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uL2FwaS9jbGllbnRcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIFJlZ2lzdGVyUGFnZSgpIHtcbiAgY29uc3QgeyByZWdpc3RlciB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBhc3luYyBmdW5jdGlvbiBvblN1Ym1pdChlOiBGb3JtRXZlbnQpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgLy8g0JHQtdC60LXQvdC0INGA0LXRlNGB0YLRgNGD0ZQg0LvQuNGI0LUg0LrQsNC90LTQuNC00LDRgtGW0LIgKGF1dGgucHk6INGW0L3RiNCwINGA0L7Qu9GMIC0+IDQwMyksXG4gICAgICAvLyDRgtC+0LYg0YDQvtC70Ywg0YLRg9GCINC90LUg0LLQuNCx0LjRgNCw0ZTRgtGM0YHRjy5cbiAgICAgIGF3YWl0IHJlZ2lzdGVyKHsgZW1haWwsIHBhc3N3b3JkLCByb2xlOiBcImNhbmRpZGF0ZVwiIH0pO1xuICAgICAgbmF2aWdhdGUoXCIvYm9hcmRcIik7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGVyci5tZXNzYWdlIDogXCLQndC1INCy0LTQsNC70L7RgdGPINC30LDRgNC10ZTRgdGC0YDRg9Cy0LDRgtC40YHRj1wiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtc2NyZWVuXCI+XG4gICAgICA8Zm9ybSBjbGFzc05hbWU9XCJhdXRoLWNhcmRcIiBvblN1Ym1pdD17b25TdWJtaXR9PlxuICAgICAgICA8aDE+VGVjaCBJbnRlcnZpZXcgQm9hcmQ8L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhdXRoLXN1YnRpdGxlXCI+XG4gICAgICAgICAg0KDQtdGU0YHRgtGA0LDRhtGW0Y8g0LrQsNC90LTQuNC00LDRgtCwIOKAlCDRgNCw0LfQvtC8INC3INCw0LrQsNGD0L3RgtC+0Lwg0YHRgtCy0L7RgNGO0ZTRgtGM0YHRjyDQstCw0YjQsCDQtNC+0YjQutCwINC3XG4gICAgICAgICAg0YfQvtGC0LjRgNC80LAg0YHRgtCw0L3QtNCw0YDRgtC90LjQvNC4INC10YLQsNC/0LDQvNC4LlxuICAgICAgICA8L3A+XG4gICAgICAgIDxsYWJlbD5cbiAgICAgICAgICBFbWFpbFxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImVtYWlsXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8bGFiZWw+XG4gICAgICAgICAg0J/QsNGA0L7Qu9GMXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgbWluTGVuZ3RoPXs4fVxuICAgICAgICAgICAgbWF4TGVuZ3RoPXsxMjh9XG4gICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJmb3JtLWVycm9yXCI+e2Vycm9yfTwvcD59XG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtsb2FkaW5nfT5cbiAgICAgICAgICB7bG9hZGluZyA/IFwi0KDQtdGU0YHRgtGA0LDRhtGW0Y8uLi5cIiA6IFwi0JfQsNGA0LXRlNGB0YLRgNGD0LLQsNGC0LjRgdGPXCJ9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhdXRoLXN3aXRjaFwiPlxuICAgICAgICAgINCS0LbQtSDRlCDQsNC60LDRg9C90YI/IDxMaW5rIHRvPVwiL2xvZ2luXCI+0KPQstGW0LnRgtC4PC9MaW5rPlxuICAgICAgICA8L3A+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9vbGVrc2lpdm9saWsvRG9jdW1lbnRzL0dpdEh1Yi9Nb25rZXktQnVzaW5lc3MtcHJvamVjdC9zcmMvZnJvbnRlbmQvc3JjL3BhZ2VzL1JlZ2lzdGVyUGFnZS50c3gifQ==