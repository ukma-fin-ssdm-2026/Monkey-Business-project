import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CardModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b39cee6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=2b39cee6"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { api, ApiError } from "/src/api/client.ts";
const STATUS_OPTIONS = [
  { value: "active", label: "Активна" },
  { value: "rejected", label: "Відмова" },
  { value: "offer_accepted", label: "Офер" }
];
const SOURCE_OPTIONS = [
  { value: "candidate", label: "Кандидат" },
  { value: "recruiter", label: "Рекрутер" },
  { value: "ai", label: "AI-асистент" }
];
function toLocalInputValue(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`;
}
export function CardModal({ boardId, card, canWrite, onClose, onUpdated, onDeleted }) {
  _s();
  const [company, setCompany] = useState(card.company);
  const [position, setPosition] = useState(card.position);
  const [vacancyUrl, setVacancyUrl] = useState(card.vacancy_url ?? "");
  const [requirements, setRequirements] = useState(card.requirements_text ?? "");
  const [deadline, setDeadline] = useState(toLocalInputValue(card.deadline));
  const [notificationsEnabled, setNotificationsEnabled] = useState(
    card.notifications_enabled
  );
  const [status, setStatus] = useState(card.status);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [links, setLinks] = useState(null);
  const [newLink, setNewLink] = useState("");
  const [notes, setNotes] = useState(null);
  const [newNote, setNewNote] = useState("");
  const [newNoteSource, setNewNoteSource] = useState("candidate");
  useEffect(() => {
    api.listLinks(boardId, card.id).then(setLinks).catch(() => setLinks([]));
    api.listNotes(boardId, card.id).then(setNotes).catch(() => setNotes([]));
  }, [card.id]);
  function buildDiff() {
    const diff = {};
    if (company.trim() !== card.company) diff.company = company.trim();
    if (position.trim() !== card.position) diff.position = position.trim();
    const urlTrimmed = vacancyUrl.trim();
    if (urlTrimmed !== (card.vacancy_url ?? "")) {
      if (urlTrimmed) diff.vacancy_url = urlTrimmed;
    }
    const reqTrimmed = requirements.trim();
    if (reqTrimmed !== (card.requirements_text ?? "")) {
      if (reqTrimmed) diff.requirements_text = reqTrimmed;
    }
    const deadlineIso = deadline ? new Date(deadline).toISOString() : "";
    if (deadlineIso !== (card.deadline ?? "")) {
      if (deadlineIso) diff.deadline = deadlineIso;
    }
    if (notificationsEnabled !== card.notifications_enabled) {
      diff.notifications_enabled = notificationsEnabled;
    }
    if (status !== card.status) diff.status = status;
    return diff;
  }
  async function handleSave(e) {
    e.preventDefault();
    const diff = buildDiff();
    if (Object.keys(diff).length === 0) {
      onClose();
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const updated = await api.updateCard(boardId, card.id, diff);
      onUpdated(updated);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося зберегти картку");
    } finally {
      setSaving(false);
    }
  }
  async function handleDelete() {
    if (!window.confirm(`Видалити картку "${card.company} — ${card.position}"?`)) return;
    try {
      await api.deleteCard(boardId, card.id);
      onDeleted(card.id);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося видалити картку");
    }
  }
  async function handleAddLink(e) {
    e.preventDefault();
    if (!newLink.trim()) return;
    try {
      const link = await api.createLink(boardId, card.id, { url: newLink.trim() });
      setLinks((prev) => [...prev ?? [], link]);
      setNewLink("");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося додати посилання");
    }
  }
  async function handleDeleteLink(linkId) {
    try {
      await api.deleteLink(boardId, card.id, linkId);
      setLinks((prev) => (prev ?? []).filter((l) => l.id !== linkId));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося видалити посилання");
    }
  }
  async function handleAddNote(e) {
    e.preventDefault();
    if (!newNote.trim()) return;
    try {
      const note = await api.createNote(boardId, card.id, {
        content: newNote.trim(),
        source: newNoteSource
      });
      setNotes((prev) => [...prev ?? [], note]);
      setNewNote("");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося додати нотатку");
    }
  }
  async function handleDeleteNote(noteId) {
    try {
      await api.deleteNote(boardId, card.id, noteId);
      setNotes((prev) => (prev ?? []).filter((n) => n.id !== noteId));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не вдалося видалити нотатку");
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "modal-overlay", onClick: onClose, children: /* @__PURE__ */ jsxDEV("div", { className: "modal-card", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "modal-header", children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Картка вакансії" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 200,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "icon-button", onClick: onClose, children: "✕" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 201,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
      lineNumber: 199,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSave, className: "modal-body", children: [
      error && /* @__PURE__ */ jsxDEV("p", { className: "form-error", children: error }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 207,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "field-row", children: [
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Компанія",
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              value: company,
              onChange: (e) => setCompany(e.target.value),
              maxLength: 200,
              disabled: !canWrite,
              required: true
            },
            void 0,
            false,
            {
              fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
              lineNumber: 212,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
          lineNumber: 210,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Посада",
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              value: position,
              onChange: (e) => setPosition(e.target.value),
              maxLength: 200,
              disabled: !canWrite,
              required: true
            },
            void 0,
            false,
            {
              fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
              lineNumber: 222,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
          lineNumber: 220,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 209,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "field-row", children: [
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Статус",
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: status,
              onChange: (e) => setStatus(e.target.value),
              disabled: !canWrite,
              children: STATUS_OPTIONS.map(
                (o) => /* @__PURE__ */ jsxDEV("option", { value: o.value, children: o.label }, o.value, false, {
                  fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
                  lineNumber: 241,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
              lineNumber: 235,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
          lineNumber: 233,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Дедлайн",
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "datetime-local",
              value: deadline,
              onChange: (e) => setDeadline(e.target.value),
              disabled: !canWrite
            },
            void 0,
            false,
            {
              fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
              lineNumber: 249,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
          lineNumber: 247,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 232,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("label", { children: [
        "Посилання на вакансію",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "url",
            value: vacancyUrl,
            onChange: (e) => setVacancyUrl(e.target.value),
            placeholder: "https://...",
            disabled: !canWrite
          },
          void 0,
          false,
          {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
            lineNumber: 260,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 258,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("label", { children: [
        "Вимоги вакансії",
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            value: requirements,
            onChange: (e) => setRequirements(e.target.value),
            maxLength: 5e3,
            rows: 4,
            disabled: !canWrite
          },
          void 0,
          false,
          {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
            lineNumber: 271,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 269,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("label", { className: "checkbox-label", children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: notificationsEnabled,
            onChange: (e) => setNotificationsEnabled(e.target.checked),
            disabled: !canWrite
          },
          void 0,
          false,
          {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
            lineNumber: 281,
            columnNumber: 13
          },
          this
        ),
        "Нагадування про дедлайн увімкнені"
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 280,
        columnNumber: 11
      }, this),
      canWrite && /* @__PURE__ */ jsxDEV("div", { className: "modal-actions", children: [
        /* @__PURE__ */ jsxDEV("button", { type: "submit", disabled: saving, children: saving ? "Збереження..." : "Зберегти" }, void 0, false, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
          lineNumber: 292,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "danger", onClick: handleDelete, children: "Видалити картку" }, void 0, false, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
          lineNumber: 295,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 291,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
      lineNumber: 206,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "modal-section", children: [
      /* @__PURE__ */ jsxDEV("h3", { children: "Посилання на тестові завдання" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 303,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { className: "simple-list", children: [
        (links ?? []).map(
          (link) => /* @__PURE__ */ jsxDEV("li", { children: [
            /* @__PURE__ */ jsxDEV("a", { href: link.url, target: "_blank", rel: "noreferrer", children: link.url }, void 0, false, {
              fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
              lineNumber: 307,
              columnNumber: 17
            }, this),
            canWrite && /* @__PURE__ */ jsxDEV("button", { className: "icon-button", onClick: () => handleDeleteLink(link.id), children: "✕" }, void 0, false, {
              fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
              lineNumber: 311,
              columnNumber: 15
            }, this)
          ] }, link.id, true, {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
            lineNumber: 306,
            columnNumber: 13
          }, this)
        ),
        links !== null && links.length === 0 && /* @__PURE__ */ jsxDEV("li", { className: "empty-hint", children: "Ще немає посилань" }, void 0, false, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
          lineNumber: 318,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 304,
        columnNumber: 11
      }, this),
      canWrite && /* @__PURE__ */ jsxDEV("form", { className: "inline-form", onSubmit: handleAddLink, children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "url",
            placeholder: "https://github.com/.../test-task",
            value: newLink,
            onChange: (e) => setNewLink(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
            lineNumber: 323,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Додати" }, void 0, false, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
          lineNumber: 329,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 322,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
      lineNumber: 302,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "modal-section", children: [
      /* @__PURE__ */ jsxDEV("h3", { children: "Нотатки та фідбек" }, void 0, false, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 335,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { className: "notes-list", children: [
        (notes ?? []).map(
          (note) => /* @__PURE__ */ jsxDEV("li", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "note-meta", children: [
              /* @__PURE__ */ jsxDEV("span", { className: `source-badge source-${note.source}`, children: SOURCE_OPTIONS.find((s) => s.value === note.source)?.label }, void 0, false, {
                fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
                lineNumber: 340,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "note-date", children: new Date(note.created_at).toLocaleString("uk-UA") }, void 0, false, {
                fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
                lineNumber: 343,
                columnNumber: 19
              }, this),
              canWrite && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  className: "icon-button",
                  onClick: () => handleDeleteNote(note.id),
                  children: "✕"
                },
                void 0,
                false,
                {
                  fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
                  lineNumber: 347,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
              lineNumber: 339,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: note.content }, void 0, false, {
              fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
              lineNumber: 355,
              columnNumber: 17
            }, this)
          ] }, note.id, true, {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
            lineNumber: 338,
            columnNumber: 13
          }, this)
        ),
        notes !== null && notes.length === 0 && /* @__PURE__ */ jsxDEV("li", { className: "empty-hint", children: "Ще немає нотаток" }, void 0, false, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
          lineNumber: 359,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 336,
        columnNumber: 11
      }, this),
      canWrite && /* @__PURE__ */ jsxDEV("form", { className: "inline-form stacked", onSubmit: handleAddNote, children: [
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            placeholder: "Текст нотатки або фідбеку",
            value: newNote,
            onChange: (e) => setNewNote(e.target.value),
            maxLength: 3e3,
            rows: 2
          },
          void 0,
          false,
          {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
            lineNumber: 364,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "inline-form-row", children: [
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: newNoteSource,
              onChange: (e) => setNewNoteSource(e.target.value),
              children: SOURCE_OPTIONS.map(
                (o) => /* @__PURE__ */ jsxDEV("option", { value: o.value, children: o.label }, o.value, false, {
                  fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
                  lineNumber: 377,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
              lineNumber: 372,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Додати нотатку" }, void 0, false, {
            fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
            lineNumber: 382,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
          lineNumber: 371,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
        lineNumber: 363,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
      lineNumber: 334,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
    lineNumber: 198,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx",
    lineNumber: 197,
    columnNumber: 5
  }, this);
}
_s(CardModal, "/zXTkqTMv9PqpaBg0PYL0Je5Y2Q=");
_c = CardModal;
var _c;
$RefreshReg$(_c, "CardModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/oleksiivolik/Documents/GitHub/Monkey-Business-project/src/frontend/src/components/CardModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0xVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZLVixTQUFvQkEsV0FBV0MsZ0JBQWdCO0FBQy9DLFNBQVNDLEtBQUtDLGdCQUFnQjtBQVU5QixNQUFNQyxpQkFBeUQ7QUFBQSxFQUM3RCxFQUFFQyxPQUFPLFVBQVVDLE9BQU8sVUFBVTtBQUFBLEVBQ3BDLEVBQUVELE9BQU8sWUFBWUMsT0FBTyxVQUFVO0FBQUEsRUFDdEMsRUFBRUQsT0FBTyxrQkFBa0JDLE9BQU8sT0FBTztBQUFDO0FBRzVDLE1BQU1DLGlCQUF5RDtBQUFBLEVBQzdELEVBQUVGLE9BQU8sYUFBYUMsT0FBTyxXQUFXO0FBQUEsRUFDeEMsRUFBRUQsT0FBTyxhQUFhQyxPQUFPLFdBQVc7QUFBQSxFQUN4QyxFQUFFRCxPQUFPLE1BQU1DLE9BQU8sY0FBYztBQUFDO0FBR3ZDLFNBQVNFLGtCQUFrQkMsS0FBNEI7QUFDckQsTUFBSSxDQUFDQSxJQUFLLFFBQU87QUFDakIsUUFBTUMsSUFBSSxJQUFJQyxLQUFLRixHQUFHO0FBQ3RCLFFBQU1HLE1BQU1BLENBQUNDLE1BQWNDLE9BQU9ELENBQUMsRUFBRUUsU0FBUyxHQUFHLEdBQUc7QUFDcEQsU0FBTyxHQUFHTCxFQUFFTSxZQUFZLENBQUMsSUFBSUosSUFBSUYsRUFBRU8sU0FBUyxJQUFJLENBQUMsQ0FBQyxJQUFJTCxJQUFJRixFQUFFUSxRQUFRLENBQUMsQ0FBQyxJQUFJTjtBQUFBQSxJQUN4RUYsRUFBRVMsU0FBUztBQUFBLEVBQ2IsQ0FBQyxJQUFJUCxJQUFJRixFQUFFVSxXQUFXLENBQUMsQ0FBQztBQUMxQjtBQVdPLGdCQUFTQyxVQUFVLEVBQUVDLFNBQVNDLE1BQU1DLFVBQVVDLFNBQVNDLFdBQVdDLFVBQWlCLEdBQUc7QUFBQUMsS0FBQTtBQUMzRixRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSTdCLFNBQVNzQixLQUFLTSxPQUFPO0FBQ25ELFFBQU0sQ0FBQ0UsVUFBVUMsV0FBVyxJQUFJL0IsU0FBU3NCLEtBQUtRLFFBQVE7QUFDdEQsUUFBTSxDQUFDRSxZQUFZQyxhQUFhLElBQUlqQyxTQUFTc0IsS0FBS1ksZUFBZSxFQUFFO0FBQ25FLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJcEMsU0FBU3NCLEtBQUtlLHFCQUFxQixFQUFFO0FBQzdFLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJdkMsU0FBU08sa0JBQWtCZSxLQUFLZ0IsUUFBUSxDQUFDO0FBQ3pFLFFBQU0sQ0FBQ0Usc0JBQXNCQyx1QkFBdUIsSUFBSXpDO0FBQUFBLElBQ3REc0IsS0FBS29CO0FBQUFBLEVBQ1A7QUFDQSxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSTVDLFNBQXFCc0IsS0FBS3FCLE1BQU07QUFDNUQsUUFBTSxDQUFDRSxRQUFRQyxTQUFTLElBQUk5QyxTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDK0MsT0FBT0MsUUFBUSxJQUFJaEQsU0FBd0IsSUFBSTtBQUV0RCxRQUFNLENBQUNpRCxPQUFPQyxRQUFRLElBQUlsRCxTQUErQixJQUFJO0FBQzdELFFBQU0sQ0FBQ21ELFNBQVNDLFVBQVUsSUFBSXBELFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUNxRCxPQUFPQyxRQUFRLElBQUl0RCxTQUErQixJQUFJO0FBQzdELFFBQU0sQ0FBQ3VELFNBQVNDLFVBQVUsSUFBSXhELFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUN5RCxlQUFlQyxnQkFBZ0IsSUFBSTFELFNBQXFCLFdBQVc7QUFFMUVELFlBQVUsTUFBTTtBQUNkRSxRQUFJMEQsVUFBVXRDLFNBQVNDLEtBQUtzQyxFQUFFLEVBQUVDLEtBQUtYLFFBQVEsRUFBRVksTUFBTSxNQUFNWixTQUFTLEVBQUUsQ0FBQztBQUN2RWpELFFBQUk4RCxVQUFVMUMsU0FBU0MsS0FBS3NDLEVBQUUsRUFBRUMsS0FBS1AsUUFBUSxFQUFFUSxNQUFNLE1BQU1SLFNBQVMsRUFBRSxDQUFDO0FBQUEsRUFFekUsR0FBRyxDQUFDaEMsS0FBS3NDLEVBQUUsQ0FBQztBQUVaLFdBQVNJLFlBQXdCO0FBQy9CLFVBQU1DLE9BQW1CLENBQUM7QUFDMUIsUUFBSXJDLFFBQVFzQyxLQUFLLE1BQU01QyxLQUFLTSxRQUFTcUMsTUFBS3JDLFVBQVVBLFFBQVFzQyxLQUFLO0FBQ2pFLFFBQUlwQyxTQUFTb0MsS0FBSyxNQUFNNUMsS0FBS1EsU0FBVW1DLE1BQUtuQyxXQUFXQSxTQUFTb0MsS0FBSztBQUNyRSxVQUFNQyxhQUFhbkMsV0FBV2tDLEtBQUs7QUFDbkMsUUFBSUMsZ0JBQWdCN0MsS0FBS1ksZUFBZSxLQUFLO0FBQzNDLFVBQUlpQyxXQUFZRixNQUFLL0IsY0FBY2lDO0FBQUFBLElBQ3JDO0FBQ0EsVUFBTUMsYUFBYWpDLGFBQWErQixLQUFLO0FBQ3JDLFFBQUlFLGdCQUFnQjlDLEtBQUtlLHFCQUFxQixLQUFLO0FBQ2pELFVBQUkrQixXQUFZSCxNQUFLNUIsb0JBQW9CK0I7QUFBQUEsSUFDM0M7QUFDQSxVQUFNQyxjQUFjL0IsV0FBVyxJQUFJNUIsS0FBSzRCLFFBQVEsRUFBRWdDLFlBQVksSUFBSTtBQUNsRSxRQUFJRCxpQkFBaUIvQyxLQUFLZ0IsWUFBWSxLQUFLO0FBQ3pDLFVBQUkrQixZQUFhSixNQUFLM0IsV0FBVytCO0FBQUFBLElBQ25DO0FBQ0EsUUFBSTdCLHlCQUF5QmxCLEtBQUtvQix1QkFBdUI7QUFDdkR1QixXQUFLdkIsd0JBQXdCRjtBQUFBQSxJQUMvQjtBQUNBLFFBQUlHLFdBQVdyQixLQUFLcUIsT0FBUXNCLE1BQUt0QixTQUFTQTtBQUMxQyxXQUFPc0I7QUFBQUEsRUFDVDtBQUVBLGlCQUFlTSxXQUFXQyxHQUFjO0FBQ3RDQSxNQUFFQyxlQUFlO0FBQ2pCLFVBQU1SLE9BQU9ELFVBQVU7QUFDdkIsUUFBSVUsT0FBT0MsS0FBS1YsSUFBSSxFQUFFVyxXQUFXLEdBQUc7QUFDbENwRCxjQUFRO0FBQ1I7QUFBQSxJQUNGO0FBQ0FzQixjQUFVLElBQUk7QUFDZEUsYUFBUyxJQUFJO0FBQ2IsUUFBSTtBQUNGLFlBQU02QixVQUFVLE1BQU01RSxJQUFJNkUsV0FBV3pELFNBQVNDLEtBQUtzQyxJQUFJSyxJQUFJO0FBQzNEeEMsZ0JBQVVvRCxPQUFPO0FBQUEsSUFDbkIsU0FBU0UsS0FBSztBQUNaL0IsZUFBUytCLGVBQWU3RSxXQUFXNkUsSUFBSUMsVUFBVSw0QkFBNEI7QUFBQSxJQUMvRSxVQUFDO0FBQ0NsQyxnQkFBVSxLQUFLO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsaUJBQWVtQyxlQUFlO0FBQzVCLFFBQUksQ0FBQ0MsT0FBT0MsUUFBUSxvQkFBb0I3RCxLQUFLTSxPQUFPLE1BQU1OLEtBQUtRLFFBQVEsSUFBSSxFQUFHO0FBQzlFLFFBQUk7QUFDRixZQUFNN0IsSUFBSW1GLFdBQVcvRCxTQUFTQyxLQUFLc0MsRUFBRTtBQUNyQ2xDLGdCQUFVSixLQUFLc0MsRUFBRTtBQUFBLElBQ25CLFNBQVNtQixLQUFLO0FBQ1ovQixlQUFTK0IsZUFBZTdFLFdBQVc2RSxJQUFJQyxVQUFVLDRCQUE0QjtBQUFBLElBQy9FO0FBQUEsRUFDRjtBQUVBLGlCQUFlSyxjQUFjYixHQUFjO0FBQ3pDQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ3RCLFFBQVFlLEtBQUssRUFBRztBQUNyQixRQUFJO0FBQ0YsWUFBTW9CLE9BQU8sTUFBTXJGLElBQUlzRixXQUFXbEUsU0FBU0MsS0FBS3NDLElBQUksRUFBRTRCLEtBQUtyQyxRQUFRZSxLQUFLLEVBQUUsQ0FBQztBQUMzRWhCLGVBQVMsQ0FBQ3VDLFNBQVMsQ0FBQyxHQUFJQSxRQUFRLElBQUtILElBQUksQ0FBQztBQUMxQ2xDLGlCQUFXLEVBQUU7QUFBQSxJQUNmLFNBQVMyQixLQUFLO0FBQ1ovQixlQUFTK0IsZUFBZTdFLFdBQVc2RSxJQUFJQyxVQUFVLDZCQUE2QjtBQUFBLElBQ2hGO0FBQUEsRUFDRjtBQUVBLGlCQUFlVSxpQkFBaUJDLFFBQWdCO0FBQzlDLFFBQUk7QUFDRixZQUFNMUYsSUFBSTJGLFdBQVd2RSxTQUFTQyxLQUFLc0MsSUFBSStCLE1BQU07QUFDN0N6QyxlQUFTLENBQUN1QyxVQUFVQSxRQUFRLElBQUlJLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRWxDLE9BQU8rQixNQUFNLENBQUM7QUFBQSxJQUNoRSxTQUFTWixLQUFLO0FBQ1ovQixlQUFTK0IsZUFBZTdFLFdBQVc2RSxJQUFJQyxVQUFVLCtCQUErQjtBQUFBLElBQ2xGO0FBQUEsRUFDRjtBQUVBLGlCQUFlZSxjQUFjdkIsR0FBYztBQUN6Q0EsTUFBRUMsZUFBZTtBQUNqQixRQUFJLENBQUNsQixRQUFRVyxLQUFLLEVBQUc7QUFDckIsUUFBSTtBQUNGLFlBQU04QixPQUFPLE1BQU0vRixJQUFJZ0csV0FBVzVFLFNBQVNDLEtBQUtzQyxJQUFJO0FBQUEsUUFDbERzQyxTQUFTM0MsUUFBUVcsS0FBSztBQUFBLFFBQ3RCaUMsUUFBUTFDO0FBQUFBLE1BQ1YsQ0FBQztBQUNESCxlQUFTLENBQUNtQyxTQUFTLENBQUMsR0FBSUEsUUFBUSxJQUFLTyxJQUFJLENBQUM7QUFDMUN4QyxpQkFBVyxFQUFFO0FBQUEsSUFDZixTQUFTdUIsS0FBSztBQUNaL0IsZUFBUytCLGVBQWU3RSxXQUFXNkUsSUFBSUMsVUFBVSwyQkFBMkI7QUFBQSxJQUM5RTtBQUFBLEVBQ0Y7QUFFQSxpQkFBZW9CLGlCQUFpQkMsUUFBZ0I7QUFDOUMsUUFBSTtBQUNGLFlBQU1wRyxJQUFJcUcsV0FBV2pGLFNBQVNDLEtBQUtzQyxJQUFJeUMsTUFBTTtBQUM3Qy9DLGVBQVMsQ0FBQ21DLFVBQVVBLFFBQVEsSUFBSUksT0FBTyxDQUFDakYsTUFBTUEsRUFBRWdELE9BQU95QyxNQUFNLENBQUM7QUFBQSxJQUNoRSxTQUFTdEIsS0FBSztBQUNaL0IsZUFBUytCLGVBQWU3RSxXQUFXNkUsSUFBSUMsVUFBVSw2QkFBNkI7QUFBQSxJQUNoRjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsU0FBU3hELFNBQ3RDLGlDQUFDLFNBQUksV0FBVSxjQUFhLFNBQVMsQ0FBQ2dELE1BQU1BLEVBQUUrQixnQkFBZ0IsR0FDNUQ7QUFBQSwyQkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSw2QkFBQyxRQUFHLCtCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUI7QUFBQSxNQUNuQix1QkFBQyxZQUFPLFdBQVUsZUFBYyxTQUFTL0UsU0FBUSxpQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUVBLHVCQUFDLFVBQUssVUFBVStDLFlBQVksV0FBVSxjQUNuQ3hCO0FBQUFBLGVBQVMsdUJBQUMsT0FBRSxXQUFVLGNBQWNBLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFFM0MsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxXQUFLO0FBQUE7QUFBQSxVQUVKO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPbkI7QUFBQUEsY0FDUCxVQUFVLENBQUM0QyxNQUFNM0MsV0FBVzJDLEVBQUVnQyxPQUFPcEcsS0FBSztBQUFBLGNBQzFDLFdBQVc7QUFBQSxjQUNYLFVBQVUsQ0FBQ21CO0FBQUFBLGNBQ1gsVUFBUTtBQUFBO0FBQUEsWUFMVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLVTtBQUFBLGFBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxXQUFLO0FBQUE7QUFBQSxVQUVKO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPTztBQUFBQSxjQUNQLFVBQVUsQ0FBQzBDLE1BQU16QyxZQUFZeUMsRUFBRWdDLE9BQU9wRyxLQUFLO0FBQUEsY0FDM0MsV0FBVztBQUFBLGNBQ1gsVUFBVSxDQUFDbUI7QUFBQUEsY0FDWCxVQUFRO0FBQUE7QUFBQSxZQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtVO0FBQUEsYUFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFdBQUs7QUFBQTtBQUFBLFVBRUo7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9vQjtBQUFBQSxjQUNQLFVBQVUsQ0FBQzZCLE1BQU01QixVQUFVNEIsRUFBRWdDLE9BQU9wRyxLQUFtQjtBQUFBLGNBQ3ZELFVBQVUsQ0FBQ21CO0FBQUFBLGNBRVZwQix5QkFBZXNHO0FBQUFBLGdCQUFJLENBQUNDLE1BQ25CLHVCQUFDLFlBQXFCLE9BQU9BLEVBQUV0RyxPQUM1QnNHLFlBQUVyRyxTQURRcUcsRUFBRXRHLE9BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBLFlBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBQ0EsdUJBQUMsV0FBSztBQUFBO0FBQUEsVUFFSjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT2tDO0FBQUFBLGNBQ1AsVUFBVSxDQUFDa0MsTUFBTWpDLFlBQVlpQyxFQUFFZ0MsT0FBT3BHLEtBQUs7QUFBQSxjQUMzQyxVQUFVLENBQUNtQjtBQUFBQTtBQUFBQSxZQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlzQjtBQUFBLGFBTnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxNQUVBLHVCQUFDLFdBQUs7QUFBQTtBQUFBLFFBRUo7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9TO0FBQUFBLFlBQ1AsVUFBVSxDQUFDd0MsTUFBTXZDLGNBQWN1QyxFQUFFZ0MsT0FBT3BHLEtBQUs7QUFBQSxZQUM3QyxhQUFZO0FBQUEsWUFDWixVQUFVLENBQUNtQjtBQUFBQTtBQUFBQSxVQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtzQjtBQUFBLFdBUHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsV0FBSztBQUFBO0FBQUEsUUFFSjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBT1k7QUFBQUEsWUFDUCxVQUFVLENBQUNxQyxNQUFNcEMsZ0JBQWdCb0MsRUFBRWdDLE9BQU9wRyxLQUFLO0FBQUEsWUFDL0MsV0FBVztBQUFBLFlBQ1gsTUFBTTtBQUFBLFlBQ04sVUFBVSxDQUFDbUI7QUFBQUE7QUFBQUEsVUFMYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLc0I7QUFBQSxXQVB4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBLHVCQUFDLFdBQU0sV0FBVSxrQkFDZjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTaUI7QUFBQUEsWUFDVCxVQUFVLENBQUNnQyxNQUFNL0Isd0JBQXdCK0IsRUFBRWdDLE9BQU9HLE9BQU87QUFBQSxZQUN6RCxVQUFVLENBQUNwRjtBQUFBQTtBQUFBQSxVQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlzQjtBQUFBO0FBQUEsV0FMeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQ0EsWUFDQyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxZQUFPLE1BQUssVUFBUyxVQUFVc0IsUUFDN0JBLG1CQUFTLGtCQUFrQixjQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsVUFBUyxTQUFTb0MsY0FBYSwrQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQTVGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEZBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsaUJBQ2pCO0FBQUEsNkJBQUMsUUFBRyw2Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsUUFBRyxXQUFVLGVBQ1ZoQztBQUFBQSxrQkFBUyxJQUFJd0Q7QUFBQUEsVUFBSSxDQUFDbkIsU0FDbEIsdUJBQUMsUUFDQztBQUFBLG1DQUFDLE9BQUUsTUFBTUEsS0FBS0UsS0FBSyxRQUFPLFVBQVMsS0FBSSxjQUNwQ0YsZUFBS0UsT0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQ2pFLFlBQ0MsdUJBQUMsWUFBTyxXQUFVLGVBQWMsU0FBUyxNQUFNbUUsaUJBQWlCSixLQUFLMUIsRUFBRSxHQUFFLGlCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQSzBCLEtBQUsxQixJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxRQUNEO0FBQUEsUUFDQVgsVUFBVSxRQUFRQSxNQUFNMkIsV0FBVyxLQUNsQyx1QkFBQyxRQUFHLFdBQVUsY0FBYSxpQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFdBZGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxNQUNDckQsWUFDQyx1QkFBQyxVQUFLLFdBQVUsZUFBYyxVQUFVOEQsZUFDdEM7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsYUFBWTtBQUFBLFlBQ1osT0FBT2xDO0FBQUFBLFlBQ1AsVUFBVSxDQUFDcUIsTUFBTXBCLFdBQVdvQixFQUFFZ0MsT0FBT3BHLEtBQUs7QUFBQTtBQUFBLFVBSjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk4QztBQUFBLFFBRTlDLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHNCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FQOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0E1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLElBRUEsdUJBQUMsYUFBUSxXQUFVLGlCQUNqQjtBQUFBLDZCQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQjtBQUFBLE1BQ3JCLHVCQUFDLFFBQUcsV0FBVSxjQUNWaUQ7QUFBQUEsa0JBQVMsSUFBSW9EO0FBQUFBLFVBQUksQ0FBQ1QsU0FDbEIsdUJBQUMsUUFDQztBQUFBLG1DQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFXLHVCQUF1QkEsS0FBS0csTUFBTSxJQUNoRDdGLHlCQUFlc0csS0FBSyxDQUFDQyxNQUFNQSxFQUFFekcsVUFBVTRGLEtBQUtHLE1BQU0sR0FBRzlGLFNBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSxhQUNiLGNBQUlLLEtBQUtzRixLQUFLYyxVQUFVLEVBQUVDLGVBQWUsT0FBTyxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQ3hGLFlBQ0M7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVMsTUFBTTZFLGlCQUFpQkosS0FBS3BDLEVBQUU7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBQ0EsdUJBQUMsT0FBR29DLGVBQUtFLFdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUI7QUFBQSxlQWpCVkYsS0FBS3BDLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxRQUNEO0FBQUEsUUFDQVAsVUFBVSxRQUFRQSxNQUFNdUIsV0FBVyxLQUNsQyx1QkFBQyxRQUFHLFdBQVUsY0FBYSxnQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQztBQUFBLFdBdkIvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsTUFDQ3JELFlBQ0MsdUJBQUMsVUFBSyxXQUFVLHVCQUFzQixVQUFVd0UsZUFDOUM7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsYUFBWTtBQUFBLFlBQ1osT0FBT3hDO0FBQUFBLFlBQ1AsVUFBVSxDQUFDaUIsTUFBTWhCLFdBQVdnQixFQUFFZ0MsT0FBT3BHLEtBQUs7QUFBQSxZQUMxQyxXQUFXO0FBQUEsWUFDWCxNQUFNO0FBQUE7QUFBQSxVQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtVO0FBQUEsUUFFVix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT3FEO0FBQUFBLGNBQ1AsVUFBVSxDQUFDZSxNQUFNZCxpQkFBaUJjLEVBQUVnQyxPQUFPcEcsS0FBbUI7QUFBQSxjQUU3REUseUJBQWVtRztBQUFBQSxnQkFBSSxDQUFDQyxNQUNuQix1QkFBQyxZQUFxQixPQUFPQSxFQUFFdEcsT0FDNUJzRyxZQUFFckcsU0FEUXFHLEVBQUV0RyxPQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQSxZQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsVUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyw4QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0M7QUFBQSxhQVh0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsU0FsREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9EQTtBQUFBLE9BNUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2TEEsS0E5TEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStMQTtBQUVKO0FBQUN1QixHQTVUZVAsV0FBUztBQUFBLEtBQVRBO0FBQVMsSUFBQTRGO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiYXBpIiwiQXBpRXJyb3IiLCJTVEFUVVNfT1BUSU9OUyIsInZhbHVlIiwibGFiZWwiLCJTT1VSQ0VfT1BUSU9OUyIsInRvTG9jYWxJbnB1dFZhbHVlIiwiaXNvIiwiZCIsIkRhdGUiLCJwYWQiLCJuIiwiU3RyaW5nIiwicGFkU3RhcnQiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZ2V0RGF0ZSIsImdldEhvdXJzIiwiZ2V0TWludXRlcyIsIkNhcmRNb2RhbCIsImJvYXJkSWQiLCJjYXJkIiwiY2FuV3JpdGUiLCJvbkNsb3NlIiwib25VcGRhdGVkIiwib25EZWxldGVkIiwiX3MiLCJjb21wYW55Iiwic2V0Q29tcGFueSIsInBvc2l0aW9uIiwic2V0UG9zaXRpb24iLCJ2YWNhbmN5VXJsIiwic2V0VmFjYW5jeVVybCIsInZhY2FuY3lfdXJsIiwicmVxdWlyZW1lbnRzIiwic2V0UmVxdWlyZW1lbnRzIiwicmVxdWlyZW1lbnRzX3RleHQiLCJkZWFkbGluZSIsInNldERlYWRsaW5lIiwibm90aWZpY2F0aW9uc0VuYWJsZWQiLCJzZXROb3RpZmljYXRpb25zRW5hYmxlZCIsIm5vdGlmaWNhdGlvbnNfZW5hYmxlZCIsInN0YXR1cyIsInNldFN0YXR1cyIsInNhdmluZyIsInNldFNhdmluZyIsImVycm9yIiwic2V0RXJyb3IiLCJsaW5rcyIsInNldExpbmtzIiwibmV3TGluayIsInNldE5ld0xpbmsiLCJub3RlcyIsInNldE5vdGVzIiwibmV3Tm90ZSIsInNldE5ld05vdGUiLCJuZXdOb3RlU291cmNlIiwic2V0TmV3Tm90ZVNvdXJjZSIsImxpc3RMaW5rcyIsImlkIiwidGhlbiIsImNhdGNoIiwibGlzdE5vdGVzIiwiYnVpbGREaWZmIiwiZGlmZiIsInRyaW0iLCJ1cmxUcmltbWVkIiwicmVxVHJpbW1lZCIsImRlYWRsaW5lSXNvIiwidG9JU09TdHJpbmciLCJoYW5kbGVTYXZlIiwiZSIsInByZXZlbnREZWZhdWx0IiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsInVwZGF0ZWQiLCJ1cGRhdGVDYXJkIiwiZXJyIiwibWVzc2FnZSIsImhhbmRsZURlbGV0ZSIsIndpbmRvdyIsImNvbmZpcm0iLCJkZWxldGVDYXJkIiwiaGFuZGxlQWRkTGluayIsImxpbmsiLCJjcmVhdGVMaW5rIiwidXJsIiwicHJldiIsImhhbmRsZURlbGV0ZUxpbmsiLCJsaW5rSWQiLCJkZWxldGVMaW5rIiwiZmlsdGVyIiwibCIsImhhbmRsZUFkZE5vdGUiLCJub3RlIiwiY3JlYXRlTm90ZSIsImNvbnRlbnQiLCJzb3VyY2UiLCJoYW5kbGVEZWxldGVOb3RlIiwibm90ZUlkIiwiZGVsZXRlTm90ZSIsInN0b3BQcm9wYWdhdGlvbiIsInRhcmdldCIsIm1hcCIsIm8iLCJjaGVja2VkIiwiZmluZCIsInMiLCJjcmVhdGVkX2F0IiwidG9Mb2NhbGVTdHJpbmciLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXJkTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICog0IbQvdGB0YLRgNGD0LzQtdC90YI6IENsYXVkZVxuICog0JfQsNGB0YLQvtGB0YPQstCw0L3QvdGPOiDQnNC+0LTQsNC70YzQvdC1INCy0ZbQutC90L4g0LrQsNGA0YLQutC4IOKAlCDRgNC10LTQsNCz0YPQstCw0L3QvdGPINC/0L7Qu9GW0LIgKFBBVENIXG4gKiAuLi4vY2FyZHMve2lkfSksINCy0LjQtNCw0LvQtdC90L3Rjywg0YHQv9C40YHQvtC6L9C00L7QtNCw0LLQsNC90L3Rjy/QstC40LTQsNC70LXQvdC90Y8g0L/QvtGB0LjQu9Cw0L3RjFxuICogKC4uLi9saW5rcykg0YLQsCDQvdC+0YLQsNGC0L7Qui/RhNGW0LTQsdC10LrRgyAoLi4uL25vdGVzKSDQv9C+INC60LDRgNGC0YbRli5cbiAqINCS0LXRgNC40YTRltC60LDRhtGW0Y86IFBBVENIINC90LDQtNGB0LjQu9Cw0ZQg0LvQuNGI0LUg0LfQvNGW0L3QtdC90ZYg0L/QvtC70Y8gKGRpZmYpLCDQsdC+IENhcmRVcGRhdGUg0YNcbiAqIHNjaGVtYXMucHkg0LLQuNC80LDQs9Cw0ZQg0YXQvtGH0LAg0LEg0L7QtNC90LUg0L/QvtC70LUg0LIgbW9kZWxfZmllbGRzX3NldDsg0Y/QstC90LUg0L7Rh9C40YnQtdC90L3Rj1xuICog0L3QtdC+0LHQvtCyJ9GP0LfQutC+0LLQvtCz0L4g0L/QvtC70Y8gKG51bGwpINC90LUg0L3QsNC00YHQuNC70LDRlNGC0YzRgdGPLCDQsdC+INCx0LXQutC10L3QtCDRgtCw0LrQuNC5IG51bGxcbiAqINGW0LPQvdC+0YDRg9GUICjQutC+0LzQtdC90YLQsNGAINGDIHJvdXRlcnMvY2FyZHMucHk6IFwib3B0aW9uYWwgZmllbGRzIGNhbm5vdCBiZVxuICogY2xlYXJlZCB5ZXRcIikg4oCUINGG0LUg0L7QsdC80LXQttC10L3QvdGPINCx0LXQutC10L3QtNGDLCDQvdC1INGE0YDQvtC90YLQtdC90LTRgy4g0J/QtdGA0LXQstGW0YDQtdC90L4g0YLQuNC/0Lgg0LlcbiAqINCx0ZbQu9C0LlxuICovXG5cbmltcG9ydCB7IEZvcm1FdmVudCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgYXBpLCBBcGlFcnJvciB9IGZyb20gXCIuLi9hcGkvY2xpZW50XCI7XG5pbXBvcnQgdHlwZSB7XG4gIENhcmRMaW5rT3V0LFxuICBDYXJkTm90ZU91dCxcbiAgQ2FyZE91dCxcbiAgQ2FyZFN0YXR1cyxcbiAgQ2FyZFVwZGF0ZSxcbiAgTm90ZVNvdXJjZSxcbn0gZnJvbSBcIi4uL2FwaS90eXBlc1wiO1xuXG5jb25zdCBTVEFUVVNfT1BUSU9OUzogeyB2YWx1ZTogQ2FyZFN0YXR1czsgbGFiZWw6IHN0cmluZyB9W10gPSBbXG4gIHsgdmFsdWU6IFwiYWN0aXZlXCIsIGxhYmVsOiBcItCQ0LrRgtC40LLQvdCwXCIgfSxcbiAgeyB2YWx1ZTogXCJyZWplY3RlZFwiLCBsYWJlbDogXCLQktGW0LTQvNC+0LLQsFwiIH0sXG4gIHsgdmFsdWU6IFwib2ZmZXJfYWNjZXB0ZWRcIiwgbGFiZWw6IFwi0J7RhNC10YBcIiB9LFxuXTtcblxuY29uc3QgU09VUkNFX09QVElPTlM6IHsgdmFsdWU6IE5vdGVTb3VyY2U7IGxhYmVsOiBzdHJpbmcgfVtdID0gW1xuICB7IHZhbHVlOiBcImNhbmRpZGF0ZVwiLCBsYWJlbDogXCLQmtCw0L3QtNC40LTQsNGCXCIgfSxcbiAgeyB2YWx1ZTogXCJyZWNydWl0ZXJcIiwgbGFiZWw6IFwi0KDQtdC60YDRg9GC0LXRgFwiIH0sXG4gIHsgdmFsdWU6IFwiYWlcIiwgbGFiZWw6IFwiQUkt0LDRgdC40YHRgtC10L3RglwiIH0sXG5dO1xuXG5mdW5jdGlvbiB0b0xvY2FsSW5wdXRWYWx1ZShpc286IHN0cmluZyB8IG51bGwpOiBzdHJpbmcge1xuICBpZiAoIWlzbykgcmV0dXJuIFwiXCI7XG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShpc28pO1xuICBjb25zdCBwYWQgPSAobjogbnVtYmVyKSA9PiBTdHJpbmcobikucGFkU3RhcnQoMiwgXCIwXCIpO1xuICByZXR1cm4gYCR7ZC5nZXRGdWxsWWVhcigpfS0ke3BhZChkLmdldE1vbnRoKCkgKyAxKX0tJHtwYWQoZC5nZXREYXRlKCkpfVQke3BhZChcbiAgICBkLmdldEhvdXJzKCksXG4gICl9OiR7cGFkKGQuZ2V0TWludXRlcygpKX1gO1xufVxuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBib2FyZElkOiBzdHJpbmc7XG4gIGNhcmQ6IENhcmRPdXQ7XG4gIGNhbldyaXRlOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvblVwZGF0ZWQ6IChjYXJkOiBDYXJkT3V0KSA9PiB2b2lkO1xuICBvbkRlbGV0ZWQ6IChjYXJkSWQ6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIENhcmRNb2RhbCh7IGJvYXJkSWQsIGNhcmQsIGNhbldyaXRlLCBvbkNsb3NlLCBvblVwZGF0ZWQsIG9uRGVsZXRlZCB9OiBQcm9wcykge1xuICBjb25zdCBbY29tcGFueSwgc2V0Q29tcGFueV0gPSB1c2VTdGF0ZShjYXJkLmNvbXBhbnkpO1xuICBjb25zdCBbcG9zaXRpb24sIHNldFBvc2l0aW9uXSA9IHVzZVN0YXRlKGNhcmQucG9zaXRpb24pO1xuICBjb25zdCBbdmFjYW5jeVVybCwgc2V0VmFjYW5jeVVybF0gPSB1c2VTdGF0ZShjYXJkLnZhY2FuY3lfdXJsID8/IFwiXCIpO1xuICBjb25zdCBbcmVxdWlyZW1lbnRzLCBzZXRSZXF1aXJlbWVudHNdID0gdXNlU3RhdGUoY2FyZC5yZXF1aXJlbWVudHNfdGV4dCA/PyBcIlwiKTtcbiAgY29uc3QgW2RlYWRsaW5lLCBzZXREZWFkbGluZV0gPSB1c2VTdGF0ZSh0b0xvY2FsSW5wdXRWYWx1ZShjYXJkLmRlYWRsaW5lKSk7XG4gIGNvbnN0IFtub3RpZmljYXRpb25zRW5hYmxlZCwgc2V0Tm90aWZpY2F0aW9uc0VuYWJsZWRdID0gdXNlU3RhdGUoXG4gICAgY2FyZC5ub3RpZmljYXRpb25zX2VuYWJsZWQsXG4gICk7XG4gIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZTxDYXJkU3RhdHVzPihjYXJkLnN0YXR1cyk7XG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgW2xpbmtzLCBzZXRMaW5rc10gPSB1c2VTdGF0ZTxDYXJkTGlua091dFtdIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtuZXdMaW5rLCBzZXROZXdMaW5rXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbbm90ZXMsIHNldE5vdGVzXSA9IHVzZVN0YXRlPENhcmROb3RlT3V0W10gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW25ld05vdGUsIHNldE5ld05vdGVdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtuZXdOb3RlU291cmNlLCBzZXROZXdOb3RlU291cmNlXSA9IHVzZVN0YXRlPE5vdGVTb3VyY2U+KFwiY2FuZGlkYXRlXCIpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYXBpLmxpc3RMaW5rcyhib2FyZElkLCBjYXJkLmlkKS50aGVuKHNldExpbmtzKS5jYXRjaCgoKSA9PiBzZXRMaW5rcyhbXSkpO1xuICAgIGFwaS5saXN0Tm90ZXMoYm9hcmRJZCwgY2FyZC5pZCkudGhlbihzZXROb3RlcykuY2F0Y2goKCkgPT4gc2V0Tm90ZXMoW10pKTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIH0sIFtjYXJkLmlkXSk7XG5cbiAgZnVuY3Rpb24gYnVpbGREaWZmKCk6IENhcmRVcGRhdGUge1xuICAgIGNvbnN0IGRpZmY6IENhcmRVcGRhdGUgPSB7fTtcbiAgICBpZiAoY29tcGFueS50cmltKCkgIT09IGNhcmQuY29tcGFueSkgZGlmZi5jb21wYW55ID0gY29tcGFueS50cmltKCk7XG4gICAgaWYgKHBvc2l0aW9uLnRyaW0oKSAhPT0gY2FyZC5wb3NpdGlvbikgZGlmZi5wb3NpdGlvbiA9IHBvc2l0aW9uLnRyaW0oKTtcbiAgICBjb25zdCB1cmxUcmltbWVkID0gdmFjYW5jeVVybC50cmltKCk7XG4gICAgaWYgKHVybFRyaW1tZWQgIT09IChjYXJkLnZhY2FuY3lfdXJsID8/IFwiXCIpKSB7XG4gICAgICBpZiAodXJsVHJpbW1lZCkgZGlmZi52YWNhbmN5X3VybCA9IHVybFRyaW1tZWQ7XG4gICAgfVxuICAgIGNvbnN0IHJlcVRyaW1tZWQgPSByZXF1aXJlbWVudHMudHJpbSgpO1xuICAgIGlmIChyZXFUcmltbWVkICE9PSAoY2FyZC5yZXF1aXJlbWVudHNfdGV4dCA/PyBcIlwiKSkge1xuICAgICAgaWYgKHJlcVRyaW1tZWQpIGRpZmYucmVxdWlyZW1lbnRzX3RleHQgPSByZXFUcmltbWVkO1xuICAgIH1cbiAgICBjb25zdCBkZWFkbGluZUlzbyA9IGRlYWRsaW5lID8gbmV3IERhdGUoZGVhZGxpbmUpLnRvSVNPU3RyaW5nKCkgOiBcIlwiO1xuICAgIGlmIChkZWFkbGluZUlzbyAhPT0gKGNhcmQuZGVhZGxpbmUgPz8gXCJcIikpIHtcbiAgICAgIGlmIChkZWFkbGluZUlzbykgZGlmZi5kZWFkbGluZSA9IGRlYWRsaW5lSXNvO1xuICAgIH1cbiAgICBpZiAobm90aWZpY2F0aW9uc0VuYWJsZWQgIT09IGNhcmQubm90aWZpY2F0aW9uc19lbmFibGVkKSB7XG4gICAgICBkaWZmLm5vdGlmaWNhdGlvbnNfZW5hYmxlZCA9IG5vdGlmaWNhdGlvbnNFbmFibGVkO1xuICAgIH1cbiAgICBpZiAoc3RhdHVzICE9PSBjYXJkLnN0YXR1cykgZGlmZi5zdGF0dXMgPSBzdGF0dXM7XG4gICAgcmV0dXJuIGRpZmY7XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTYXZlKGU6IEZvcm1FdmVudCkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCBkaWZmID0gYnVpbGREaWZmKCk7XG4gICAgaWYgKE9iamVjdC5rZXlzKGRpZmYpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgb25DbG9zZSgpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRTYXZpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCBhcGkudXBkYXRlQ2FyZChib2FyZElkLCBjYXJkLmlkLCBkaWZmKTtcbiAgICAgIG9uVXBkYXRlZCh1cGRhdGVkKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEFwaUVycm9yID8gZXJyLm1lc3NhZ2UgOiBcItCd0LUg0LLQtNCw0LvQvtGB0Y8g0LfQsdC10YDQtdCz0YLQuCDQutCw0YDRgtC60YNcIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlRGVsZXRlKCkge1xuICAgIGlmICghd2luZG93LmNvbmZpcm0oYNCS0LjQtNCw0LvQuNGC0Lgg0LrQsNGA0YLQutGDIFwiJHtjYXJkLmNvbXBhbnl9IOKAlCAke2NhcmQucG9zaXRpb259XCI/YCkpIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXBpLmRlbGV0ZUNhcmQoYm9hcmRJZCwgY2FyZC5pZCk7XG4gICAgICBvbkRlbGV0ZWQoY2FyZC5pZCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGVyci5tZXNzYWdlIDogXCLQndC1INCy0LTQsNC70L7RgdGPINCy0LjQtNCw0LvQuNGC0Lgg0LrQsNGA0YLQutGDXCIpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFkZExpbmsoZTogRm9ybUV2ZW50KSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICghbmV3TGluay50cmltKCkpIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgY29uc3QgbGluayA9IGF3YWl0IGFwaS5jcmVhdGVMaW5rKGJvYXJkSWQsIGNhcmQuaWQsIHsgdXJsOiBuZXdMaW5rLnRyaW0oKSB9KTtcbiAgICAgIHNldExpbmtzKChwcmV2KSA9PiBbLi4uKHByZXYgPz8gW10pLCBsaW5rXSk7XG4gICAgICBzZXROZXdMaW5rKFwiXCIpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwi0J3QtSDQstC00LDQu9C+0YHRjyDQtNC+0LTQsNGC0Lgg0L/QvtGB0LjQu9Cw0L3QvdGPXCIpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZURlbGV0ZUxpbmsobGlua0lkOiBzdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXBpLmRlbGV0ZUxpbmsoYm9hcmRJZCwgY2FyZC5pZCwgbGlua0lkKTtcbiAgICAgIHNldExpbmtzKChwcmV2KSA9PiAocHJldiA/PyBbXSkuZmlsdGVyKChsKSA9PiBsLmlkICE9PSBsaW5rSWQpKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEFwaUVycm9yID8gZXJyLm1lc3NhZ2UgOiBcItCd0LUg0LLQtNCw0LvQvtGB0Y8g0LLQuNC00LDQu9C40YLQuCDQv9C+0YHQuNC70LDQvdC90Y9cIik7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlQWRkTm90ZShlOiBGb3JtRXZlbnQpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFuZXdOb3RlLnRyaW0oKSkgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBub3RlID0gYXdhaXQgYXBpLmNyZWF0ZU5vdGUoYm9hcmRJZCwgY2FyZC5pZCwge1xuICAgICAgICBjb250ZW50OiBuZXdOb3RlLnRyaW0oKSxcbiAgICAgICAgc291cmNlOiBuZXdOb3RlU291cmNlLFxuICAgICAgfSk7XG4gICAgICBzZXROb3RlcygocHJldikgPT4gWy4uLihwcmV2ID8/IFtdKSwgbm90ZV0pO1xuICAgICAgc2V0TmV3Tm90ZShcIlwiKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEFwaUVycm9yID8gZXJyLm1lc3NhZ2UgOiBcItCd0LUg0LLQtNCw0LvQvtGB0Y8g0LTQvtC00LDRgtC4INC90L7RgtCw0YLQutGDXCIpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZURlbGV0ZU5vdGUobm90ZUlkOiBzdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXBpLmRlbGV0ZU5vdGUoYm9hcmRJZCwgY2FyZC5pZCwgbm90ZUlkKTtcbiAgICAgIHNldE5vdGVzKChwcmV2KSA9PiAocHJldiA/PyBbXSkuZmlsdGVyKChuKSA9PiBuLmlkICE9PSBub3RlSWQpKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEFwaUVycm9yID8gZXJyLm1lc3NhZ2UgOiBcItCd0LUg0LLQtNCw0LvQvtGB0Y8g0LLQuNC00LDQu9C40YLQuCDQvdC+0YLQsNGC0LrRg1wiKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtb3ZlcmxheVwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1jYXJkXCIgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICAgIDxoMj7QmtCw0YDRgtC60LAg0LLQsNC60LDQvdGB0ZbRlzwvaDI+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJpY29uLWJ1dHRvblwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxuICAgICAgICAgICAg4pyVXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlfSBjbGFzc05hbWU9XCJtb2RhbC1ib2R5XCI+XG4gICAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImZvcm0tZXJyb3JcIj57ZXJyb3J9PC9wPn1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmllbGQtcm93XCI+XG4gICAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICAgINCa0L7QvNC/0LDQvdGW0Y9cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdmFsdWU9e2NvbXBhbnl9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb21wYW55KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezIwMH1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWNhbldyaXRlfVxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGxhYmVsPlxuICAgICAgICAgICAgICDQn9C+0YHQsNC00LBcbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdmFsdWU9e3Bvc2l0aW9ufVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UG9zaXRpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIG1heExlbmd0aD17MjAwfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXshY2FuV3JpdGV9XG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpZWxkLXJvd1wiPlxuICAgICAgICAgICAgPGxhYmVsPlxuICAgICAgICAgICAgICDQodGC0LDRgtGD0YFcbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIHZhbHVlPXtzdGF0dXN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdGF0dXMoZS50YXJnZXQudmFsdWUgYXMgQ2FyZFN0YXR1cyl9XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5Xcml0ZX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtTVEFUVVNfT1BUSU9OUy5tYXAoKG8pID0+IChcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtvLnZhbHVlfSB2YWx1ZT17by52YWx1ZX0+XG4gICAgICAgICAgICAgICAgICAgIHtvLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgICAg0JTQtdC00LvQsNC50L1cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cImRhdGV0aW1lLWxvY2FsXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZGVhZGxpbmV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREZWFkbGluZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5Xcml0ZX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICDQn9C+0YHQuNC70LDQvdC90Y8g0L3QsCDQstCw0LrQsNC90YHRltGOXG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInVybFwiXG4gICAgICAgICAgICAgIHZhbHVlPXt2YWNhbmN5VXJsfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFZhY2FuY3lVcmwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImh0dHBzOi8vLi4uXCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5Xcml0ZX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgINCS0LjQvNC+0LPQuCDQstCw0LrQsNC90YHRltGXXG4gICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgdmFsdWU9e3JlcXVpcmVtZW50c31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZXF1aXJlbWVudHMoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBtYXhMZW5ndGg9ezUwMDB9XG4gICAgICAgICAgICAgIHJvd3M9ezR9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXshY2FuV3JpdGV9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY2hlY2tib3gtbGFiZWxcIj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICBjaGVja2VkPXtub3RpZmljYXRpb25zRW5hYmxlZH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROb3RpZmljYXRpb25zRW5hYmxlZChlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5Xcml0ZX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICDQndCw0LPQsNC00YPQstCw0L3QvdGPINC/0YDQviDQtNC10LTQu9Cw0LnQvSDRg9Cy0ZbQvNC60L3QtdC90ZZcbiAgICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgICAge2NhbldyaXRlICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYWN0aW9uc1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17c2F2aW5nfT5cbiAgICAgICAgICAgICAgICB7c2F2aW5nID8gXCLQl9Cx0LXRgNC10LbQtdC90L3Rjy4uLlwiIDogXCLQl9Cx0LXRgNC10LPRgtC4XCJ9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJkYW5nZXJcIiBvbkNsaWNrPXtoYW5kbGVEZWxldGV9PlxuICAgICAgICAgICAgICAgINCS0LjQtNCw0LvQuNGC0Lgg0LrQsNGA0YLQutGDXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm1vZGFsLXNlY3Rpb25cIj5cbiAgICAgICAgICA8aDM+0J/QvtGB0LjQu9Cw0L3QvdGPINC90LAg0YLQtdGB0YLQvtCy0ZYg0LfQsNCy0LTQsNC90L3RjzwvaDM+XG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNpbXBsZS1saXN0XCI+XG4gICAgICAgICAgICB7KGxpbmtzID8/IFtdKS5tYXAoKGxpbmspID0+IChcbiAgICAgICAgICAgICAgPGxpIGtleT17bGluay5pZH0+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj17bGluay51cmx9IHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vcmVmZXJyZXJcIj5cbiAgICAgICAgICAgICAgICAgIHtsaW5rLnVybH1cbiAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAge2NhbldyaXRlICYmIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiaWNvbi1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVMaW5rKGxpbmsuaWQpfT5cbiAgICAgICAgICAgICAgICAgICAg4pyVXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICB7bGlua3MgIT09IG51bGwgJiYgbGlua3MubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImVtcHR5LWhpbnRcIj7QqdC1INC90LXQvNCw0ZQg0L/QvtGB0LjQu9Cw0L3RjDwvbGk+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgICAge2NhbldyaXRlICYmIChcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cImlubGluZS1mb3JtXCIgb25TdWJtaXQ9e2hhbmRsZUFkZExpbmt9PlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidXJsXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImh0dHBzOi8vZ2l0aHViLmNvbS8uLi4vdGVzdC10YXNrXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bmV3TGlua31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0xpbmsoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj7QlNC+0LTQsNGC0Lg8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICApfVxuICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibW9kYWwtc2VjdGlvblwiPlxuICAgICAgICAgIDxoMz7QndC+0YLQsNGC0LrQuCDRgtCwINGE0ZbQtNCx0LXQujwvaDM+XG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm5vdGVzLWxpc3RcIj5cbiAgICAgICAgICAgIHsobm90ZXMgPz8gW10pLm1hcCgobm90ZSkgPT4gKFxuICAgICAgICAgICAgICA8bGkga2V5PXtub3RlLmlkfT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdGUtbWV0YVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgc291cmNlLWJhZGdlIHNvdXJjZS0ke25vdGUuc291cmNlfWB9PlxuICAgICAgICAgICAgICAgICAgICB7U09VUkNFX09QVElPTlMuZmluZCgocykgPT4gcy52YWx1ZSA9PT0gbm90ZS5zb3VyY2UpPy5sYWJlbH1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm5vdGUtZGF0ZVwiPlxuICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUobm90ZS5jcmVhdGVkX2F0KS50b0xvY2FsZVN0cmluZyhcInVrLVVBXCIpfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2NhbldyaXRlICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImljb24tYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVOb3RlKG5vdGUuaWQpfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAg4pyVXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8cD57bm90ZS5jb250ZW50fTwvcD5cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgICAge25vdGVzICE9PSBudWxsICYmIG5vdGVzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJlbXB0eS1oaW50XCI+0KnQtSDQvdC10LzQsNGUINC90L7RgtCw0YLQvtC6PC9saT5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgICB7Y2FuV3JpdGUgJiYgKFxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiaW5saW5lLWZvcm0gc3RhY2tlZFwiIG9uU3VibWl0PXtoYW5kbGVBZGROb3RlfT5cbiAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLQotC10LrRgdGCINC90L7RgtCw0YLQutC4INCw0LHQviDRhNGW0LTQsdC10LrRg1wiXG4gICAgICAgICAgICAgICAgdmFsdWU9e25ld05vdGV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdOb3RlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezMwMDB9XG4gICAgICAgICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZm9ybS1yb3dcIj5cbiAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3Tm90ZVNvdXJjZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3Tm90ZVNvdXJjZShlLnRhcmdldC52YWx1ZSBhcyBOb3RlU291cmNlKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7U09VUkNFX09QVElPTlMubWFwKChvKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtvLnZhbHVlfSB2YWx1ZT17by52YWx1ZX0+XG4gICAgICAgICAgICAgICAgICAgICAge28ubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+0JTQvtC00LDRgtC4INC90L7RgtCw0YLQutGDPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvb2xla3NpaXZvbGlrL0RvY3VtZW50cy9HaXRIdWIvTW9ua2V5LUJ1c2luZXNzLXByb2plY3Qvc3JjL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0NhcmRNb2RhbC50c3gifQ==